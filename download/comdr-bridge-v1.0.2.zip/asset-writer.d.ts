export declare class AssetWriter {
    private _projectPath;
    constructor(projectPath: string);
    writeAsset(payload: Record<string, unknown>, skipRefresh?: boolean): Promise<unknown>;
    private _verifyWriteback;
    private _generateMeta;
}
/** 拷贝文件或文件夹。文件系统直判类型，不限文件格式。
 *  destPath 可选: 指定目标路径（跳过自动 _1 防同名） */
export declare function copyFileOrFolder(projectPath: string, sourcePath: string, destPath?: string): Promise<Record<string, unknown>>;
/** remap-refs — 将 target 中所有匹配 from→to 的 __uuid__ 引用替换
 *
 *  from/to 可以是单个文件或文件夹。
 *  文件夹模式：同相对路径配对 oldUuid→newUuid。
 *  target 可以是单个文件或文件夹。
 *  不限文件类型 — 有 .meta 即处理。
 */
export declare function remapRefs(projectPath: string, targetPath: string, fromPath: string, toPath: string): Promise<Record<string, unknown>>;
//# sourceMappingURL=asset-writer.d.ts.map