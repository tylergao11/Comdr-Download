/** 原子写入 JSON 文件：先写 tmp 再 rename，防止崩溃损坏用户资产 */
export declare function writeJsonAtomic(filePath: string, data: unknown): void;
/** 原子写入文件内容：先写 tmp 再 rename，跨设备 link 时 fallback 直接写入 */
export declare function writeFileAtomic(filePath: string, content: string): void;
//# sourceMappingURL=fs-utils.d.ts.map