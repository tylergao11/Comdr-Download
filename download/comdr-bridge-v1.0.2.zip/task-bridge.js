"use strict";
// ============================================================
// TaskBridge — 文件 IPC 轮询机制
// 轮询 temp/comdr/inbox/ → 执行 → 写 temp/comdr/outbox/
// ============================================================
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.TaskBridge = void 0;
const fs = __importStar(require("fs"));
const path = __importStar(require("path"));
const version_1 = require("./version");
const fs_utils_1 = require("./fs-utils");
const BRIDGE_SCHEMA = 'Comdr.cocos-task-bridge.v1';
// ── 镜像 foundation 常量（bridge 独立部署不能 import，修改时必须两边同步）──
const REQUEST_SCHEMA = 'Comdr.cocos-task-request.v1'; // → SCHEMA_TASK_REQUEST
const RESULT_SCHEMA = 'Comdr.cocos-task-result.v1'; // → SCHEMA_TASK_RESULT
const COMDR_TEMP = 'temp/comdr'; // → COMDR_TEMP_DIR
const IPC_POLL_DEFAULT_MS = 250; // → IPC_POLL_MS
const IPC_TIMEOUT_DEFAULT_MS = 120_000; // → IPC_TIMEOUT_MS
const HEARTBEAT_SCHEMA_VERSION = '2.0.0';
class TaskBridge {
    _opts;
    _watcher = null;
    _heartbeatTimer = null;
    _processing = false;
    _engineSourceInfo = null;
    _engineSourceDiscovered = false;
    _internalAssetInfo = null;
    _internalAssetDiscovered = false;
    _systemsReady = false;
    // component-cache.json 内存缓存（心跳每 250ms 触发，避免高频同步读盘+JSON.parse）
    _componentSchemaCache = null;
    constructor(options) {
        this._opts = {
            intervalMs: IPC_POLL_DEFAULT_MS,
            taskTimeoutMs: IPC_TIMEOUT_DEFAULT_MS,
            getEditorAppPath: () => '',
            getOpenDocument: () => null,
            ...options,
        };
    }
    start() {
        const dirs = this._getDirs();
        fs.mkdirSync(dirs.inbox, { recursive: true });
        fs.mkdirSync(dirs.processing, { recursive: true });
        fs.mkdirSync(dirs.outbox, { recursive: true });
        this._recoverProcessing(dirs);
        this._writeHeartbeat(dirs);
        // fs.watch 替代 setInterval 轮询——ToolCenter 写入 inbox 瞬间 Bridge 就能响应
        this._watcher = fs.watch(dirs.inbox, (_event, _filename) => {
            this._tick(dirs).catch((e) => { process.stderr.write(`[comdr] tick error: ${(e instanceof Error ? e.message : String(e))}\n`); });
        });
        // 心跳独立于任务处理，保持定期写入（Gateway 靠心跳判断 Bridge 存活）
        this._heartbeatTimer = setInterval(() => {
            this._writeHeartbeat(dirs);
        }, this._opts.intervalMs);
        if (this._heartbeatTimer.unref)
            this._heartbeatTimer.unref();
    }
    stop() {
        if (this._watcher) {
            try {
                this._watcher.close();
            }
            catch { /* */ }
        }
        this._watcher = null;
        if (this._heartbeatTimer)
            clearInterval(this._heartbeatTimer);
        this._heartbeatTimer = null;
    }
    /** 所有子系统就绪后由 load() 调用，Gateway 据此判断是否可以开始处理任务 */
    setSystemsReady() {
        this._systemsReady = true;
    }
    // ===== 内部 =====
    _getDirs() {
        const projectPath = this._opts.getProjectPath();
        const root = path.join(projectPath, COMDR_TEMP);
        return {
            root,
            inbox: path.join(root, 'inbox'),
            processing: path.join(root, 'processing'),
            outbox: path.join(root, 'outbox'),
        };
    }
    async _tick(dirs) {
        if (this._processing)
            return;
        this._processing = true;
        try {
            // 排干所有积压文件，不依赖 fs.watch 逐个触发
            while (true) {
                const files = fs.readdirSync(dirs.inbox)
                    .filter((f) => f.endsWith('.json'))
                    .sort();
                this._writeHeartbeat(dirs);
                if (files.length === 0)
                    break;
                await this._processFile(dirs, files[0]);
            }
        }
        finally {
            this._processing = false;
            // 防御孤儿文件：处理期间 fs.watch 可能触发但被 _processing 守卫吞掉，
            // 释放锁后若 inbox 仍有残留文件则重调度（下一轮事件循环执行）
            const remaining = fs.readdirSync(dirs.inbox).filter((f) => f.endsWith('.json'));
            if (remaining.length > 0) {
                setImmediate(() => this._tick(dirs));
            }
        }
    }
    async _processFile(dirs, fileName) {
        const source = path.join(dirs.inbox, fileName);
        const working = path.join(dirs.processing, fileName);
        // 原子认领
        try {
            fs.renameSync(source, working);
        }
        catch (e) {
            process.stderr.write(`[comdr] rename claims failed: ${(e instanceof Error ? e.message : String(e))}\n`);
            return;
        }
        const startedAt = new Date().toISOString();
        let request = {};
        try {
            const raw = fs.readFileSync(working, 'utf8').replace(/^﻿/, '');
            request = JSON.parse(raw);
            if (request.schema !== REQUEST_SCHEMA) {
                throw new Error(`Unsupported schema: ${request.schema}`);
            }
            const taskCard = request.taskCard;
            if (!taskCard || typeof taskCard !== 'object') {
                throw new Error('Missing taskCard');
            }
            // 执行（带超时）
            const result = await this._withTimeout(this._opts.runTaskCard(taskCard), this._opts.taskTimeoutMs);
            this._writeResult(dirs, request, {
                ok: true,
                result,
                startedAt,
                finishedAt: new Date().toISOString(),
            });
        }
        catch (err) {
            this._writeResult(dirs, request, {
                ok: false,
                error: err instanceof Error ? err.message : String(err),
                startedAt,
                finishedAt: new Date().toISOString(),
            });
        }
        finally {
            try {
                fs.rmSync(working, { force: true });
            }
            catch { /* ignore */ }
        }
    }
    _writeResult(dirs, request, result) {
        const id = String(request.id || `task-${Date.now()}`);
        const target = path.join(dirs.outbox, `${id}.json`);
        const payload = {
            schema: RESULT_SCHEMA,
            id,
            ...result,
        };
        // 原子写入
        (0, fs_utils_1.writeFileAtomic)(target, JSON.stringify(payload, null, 2) + '\n');
    }
    _recoverProcessing(dirs) {
        if (!fs.existsSync(dirs.processing))
            return;
        const files = fs.readdirSync(dirs.processing)
            .filter((f) => f.endsWith('.json'));
        for (const fileName of files) {
            const working = path.join(dirs.processing, fileName);
            this._writeResult(dirs, { id: path.basename(fileName, '.json') }, {
                ok: false,
                error: 'Recovered stale request after bridge restart',
                recovered: true,
                startedAt: null,
                finishedAt: new Date().toISOString(),
            });
            try {
                fs.rmSync(working, { force: true });
            }
            catch { /* ignore */ }
        }
    }
    _discoverEngineSource() {
        if (this._engineSourceDiscovered)
            return this._engineSourceInfo || { available: false };
        this._engineSourceDiscovered = true;
        const editorAppPath = this._opts.getEditorAppPath();
        if (!editorAppPath) {
            this._engineSourceInfo = { available: false, reason: 'no editor path' };
            return this._engineSourceInfo;
        }
        // 从 app.asar 路径推导编辑器根目录
        const editorRoot = path.dirname(editorAppPath);
        const engineCocosPath = path.join(editorRoot, 'resources', 'resources', '3d', 'engine', 'cocos');
        if (fs.existsSync(engineCocosPath)) {
            // 尝试读版本号
            let version = '';
            try {
                const infoPath = path.join(editorRoot, 'resources', 'info.json');
                if (fs.existsSync(infoPath)) {
                    const info = JSON.parse(fs.readFileSync(infoPath, 'utf8'));
                    version = info.version || '';
                }
            }
            catch { /* ignore */ }
            this._engineSourceInfo = {
                available: true,
                path: engineCocosPath,
                version: version || '3.x',
            };
        }
        else {
            this._engineSourceInfo = { available: false, reason: 'engine cocos dir not found' };
        }
        return this._engineSourceInfo;
    }
    /** 加载 sync 脚本预提取的 internal 资产目录（构建时生成，零运行时路径依赖） */
    _discoverInternalAssets() {
        if (this._internalAssetDiscovered)
            return this._internalAssetInfo || {};
        this._internalAssetDiscovered = true;
        // sync-bridge 脚本在构建时将 internal-assets.json 写入 dist
        const cachePath = path.join(__dirname, 'internal-assets.json');
        try {
            if (fs.existsSync(cachePath)) {
                const cache = JSON.parse(fs.readFileSync(cachePath, 'utf8'));
                if (cache.schema === 'Comdr.internal-assets.v1' && cache.assets) {
                    this._internalAssetInfo = cache.assets;
                    return this._internalAssetInfo;
                }
            }
        }
        catch (e) {
            process.stderr.write(`[comdr] internal assets cache load failed: ${(e instanceof Error ? e.message : String(e))}\n`);
        }
        this._internalAssetInfo = {};
        return {};
    }
    _writeHeartbeat(dirs) {
        const cachePath = path.join(dirs.root, 'component-cache.json');
        let componentSchema = { working: false };
        // 内存缓存：只有文件 mtime 变化时才重新读盘+JSON.parse（心跳每 250ms 触发）
        try {
            if (fs.existsSync(cachePath)) {
                const stat = fs.statSync(cachePath);
                const mtimeMs = stat.mtimeMs;
                if (this._componentSchemaCache && this._componentSchemaCache.mtimeMs === mtimeMs) {
                    componentSchema = this._componentSchemaCache.schema;
                }
                else {
                    const cache = JSON.parse(fs.readFileSync(cachePath, 'utf8'));
                    const comps = cache.components || {};
                    componentSchema = {
                        working: true,
                        count: Object.keys(comps).length,
                        source: cache.source || 'engine-ts-source',
                        version: cache.version || '',
                    };
                    this._componentSchemaCache = { mtimeMs, schema: componentSchema };
                }
            }
        }
        catch { /* component cache not ready yet */ }
        const engineSource = this._discoverEngineSource();
        const internalAssets = this._discoverInternalAssets();
        const openDoc = this._opts.getOpenDocument?.() || null;
        // 心跳结构须与 core/src/tool-center.ts:BridgeHeartbeatInfo 兼容
        const info = {
            schema: BRIDGE_SCHEMA,
            projectPath: this._opts.getProjectPath(),
            openDocument: openDoc ? { kind: openDoc.kind, path: openDoc.path, name: openDoc.name, rootNodeUuid: openDoc.rootNodeUuid || '' } : null,
            root: dirs.root,
            inbox: dirs.inbox,
            processing: dirs.processing,
            outbox: dirs.outbox,
            updatedAt: new Date().toISOString(),
            editorCapabilities: {
                version: HEARTBEAT_SCHEMA_VERSION,
                bridgeVersion: version_1.VERSION,
                ready: this._systemsReady,
                probedAt: new Date().toISOString(),
                componentSchema,
                assetWrite: { working: true },
                documentSerialize: { working: true },
                engineSource,
                internalAssets: Object.keys(internalAssets).length > 0 ? internalAssets : undefined,
            },
        };
        const bp = path.join(dirs.root, 'bridge.json');
        (0, fs_utils_1.writeFileAtomic)(bp, JSON.stringify(info, null, 2) + '\n');
    }
    _withTimeout(promise, ms) {
        let timer;
        const timeout = new Promise((_, reject) => {
            timer = setTimeout(() => reject(new Error(`Task timeout after ${ms}ms`)), ms);
        });
        return Promise.race([promise, timeout]).finally(() => clearTimeout(timer));
    }
}
exports.TaskBridge = TaskBridge;
//# sourceMappingURL=task-bridge.js.map