"use strict";
// ============================================================
// NodeResolver — 文档节点引用解析器
// 三级匹配：fileId → 路径 → 模糊名（精确>substring>Levenshtein）
// 从 Document 类中提取，与 JSON 读写解耦
// ============================================================
Object.defineProperty(exports, "__esModule", { value: true });
exports.NodeResolver = void 0;
const levenshtein_1 = require("./utils/levenshtein");
const error_codes_1 = require("./error-codes");
// ── 镜像 document.ts 常量 ──
const NODE_LIKE_TYPES = new Set(['cc.Node', 'cc.Scene']);
// ===== 工具 =====
function _isNodeOrScene(typeName) {
    return typeName !== undefined && NODE_LIKE_TYPES.has(typeName);
}
// ===== NodeResolver 类 =====
class NodeResolver {
    _json;
    // 模糊名索引（name → 命中列表），_buildTree 时构建，O(1) 查找
    _nodeFlatIndex = [];
    // 节点级 fileId → _json 数组索引（覆盖所有节点，_buildTree 时构建）
    _nodeIdIndex = null;
    // findNode 加速：fileId → PrefabInfo 在 _json 中的索引，惰性构建
    _prefabInfoIndex = null;
    // findComponent 加速：CompPrefabInfo 索引 → 引用它的 Component 索引，惰性构建
    _compToCpiIndex = null;
    constructor(json) {
        this._json = json;
    }
    /** JSON 引用更新时调用（edit 后 _json 可能被替换） */
    updateJson(json) {
        this._json = json;
        this._invalidateCaches();
    }
    // ===== FindNode =====
    findNode(fileId) {
        // 1. 节点级索引（_buildTree 构建，覆盖所有节点，唯一真实源）
        if (this._nodeIdIndex) {
            const nodeIdx = this._nodeIdIndex.get(fileId);
            if (nodeIdx !== undefined && nodeIdx >= 0 && nodeIdx < this._json.length) {
                const nodeObj = this._json[nodeIdx];
                if (nodeObj && !nodeObj.__deleted__ && _isNodeOrScene(nodeObj.__type__)) {
                    const prefabRef = nodeObj._prefab;
                    const piIdx = prefabRef?.__id__;
                    const prefabInfo = (piIdx != null && piIdx >= 0 && piIdx < this._json.length)
                        ? this._json[piIdx] : null;
                    return {
                        nodeObj,
                        nodeIndex: nodeIdx,
                        prefabInfo: prefabInfo || {},
                        prefabInfoIndex: piIdx ?? -1,
                    };
                }
            }
        }
        // 2. PrefabInfo 索引回退
        this._ensurePrefabInfoIndex();
        const piIdx = this._prefabInfoIndex.get(fileId);
        if (piIdx !== undefined) {
            for (let j = 0; j < this._json.length; j++) {
                const nodeObj = this._json[j];
                if (nodeObj && !nodeObj.__deleted__ && _isNodeOrScene(nodeObj.__type__) && nodeObj._prefab?.__id__ === piIdx) {
                    return { nodeObj, nodeIndex: j, prefabInfo: this._json[piIdx], prefabInfoIndex: piIdx };
                }
            }
        }
        return null;
    }
    // ===== FindComponent =====
    findComponent(fileId) {
        this._ensureCompToCpiIndex();
        for (let i = 0; i < this._json.length; i++) {
            const obj = this._json[i];
            if (obj && !obj.__deleted__ && obj.__type__ === 'cc.CompPrefabInfo' && obj.fileId === fileId) {
                const compIdx = this._compToCpiIndex.get(i);
                if (compIdx !== undefined) {
                    const compObj = this._json[compIdx];
                    if (compObj && !compObj.__deleted__) {
                        return { compObj, compIndex: compIdx, compPrefabInfo: obj, compPrefabInfoIndex: i, fileId: obj.fileId || '' };
                    }
                }
                return null;
            }
        }
        return null;
    }
    findComponentByType(nodeFileId, componentType) {
        const nodeFound = this.findNode(nodeFileId);
        if (!nodeFound)
            return null;
        const compRefs = nodeFound.nodeObj._components || [];
        for (const ref of compRefs) {
            const compIdx = ref.__id__;
            if (compIdx < 0 || compIdx >= this._json.length)
                continue;
            const compObj = this._json[compIdx];
            if (compObj && !compObj.__deleted__ && compObj.__type__ === componentType) {
                const cpiRef = compObj.__prefab;
                const cpiIdx = cpiRef?.__id__ != null ? cpiRef.__id__ : -1;
                const cpi = cpiIdx >= 0 ? this._json[cpiIdx] : null;
                const cpiFileId = (cpi && cpi.fileId) || '';
                return { compObj, compIndex: compIdx, compPrefabInfo: cpi || {}, compPrefabInfoIndex: cpiIdx, fileId: cpiFileId };
            }
        }
        return null;
    }
    // ===== 节点引用解析 =====
    /** 统一节点引用解析入口。
     *  接受 #fileId / 路径 / 模糊名，返回 FindNodeResult 或错误。 */
    resolveNodeRef(ref) {
        if (!ref)
            return { ok: false, error: 'Missing node reference', code: error_codes_1.ERR_DOC_NODE_NOT_FOUND };
        const trimmed = ref.trim().startsWith('#') ? ref.trim().slice(1) : ref.trim();
        if (!trimmed)
            return { ok: false, error: 'Missing node reference', code: error_codes_1.ERR_DOC_NODE_NOT_FOUND };
        // 1. 直接查 fileId
        const byId = this.findNode(trimmed);
        if (byId)
            return byId;
        // 2. 路径匹配
        if (trimmed.startsWith('/') || trimmed.includes('/')) {
            const path = trimmed.startsWith('/') ? trimmed.slice(1) : trimmed;
            for (const entry of this._nodeFlatIndex) {
                if (entry.path === path) {
                    return this.findNode(entry.fileId) || { ok: false, error: `Node not found: ${trimmed}`, code: error_codes_1.ERR_DOC_NODE_NOT_FOUND };
                }
            }
            return { ok: false, error: `Node not found at path: ${trimmed}. Use >retrieve(probe=find-in-doc, name=...) or a #fileId.`, code: error_codes_1.ERR_DOC_NODE_NOT_FOUND };
        }
        // 3. 模糊名 — 精确匹配优先，回退 substring，再回退 Levenshtein
        const matches = this._fuzzyMatchNames(trimmed);
        if (matches.length === 1) {
            return this.findNode(matches[0].fileId) || { ok: false, error: `Node not found: ${trimmed}`, code: error_codes_1.ERR_DOC_NODE_NOT_FOUND };
        }
        if (matches.length > 1) {
            return {
                ok: false,
                error: `Ambiguous name '${trimmed}': ${matches.length} matches. Use fileId or full path.`,
                code: error_codes_1.ERR_DOC_AMBIGUOUS_NODE,
                matches: matches.map((m) => ({ name: m.name, path: '/' + m.path, fileId: m.fileId })),
            };
        }
        return { ok: false, error: `Node not found: ${trimmed}. Use >retrieve(probe=find-in-doc, name=${trimmed}) first, then use the returned #fileId.`, code: error_codes_1.ERR_DOC_NODE_NOT_FOUND };
    }
    /** 模糊名匹配引擎 */
    _fuzzyMatchNames(query, max = 20) {
        if (!query)
            return [];
        const lower = query.toLowerCase();
        const exacts = [];
        const subs = [];
        const fuzzy = [];
        for (const entry of this._nodeFlatIndex) {
            const nl = entry.name.toLowerCase();
            if (nl === lower) {
                exacts.push(entry);
            }
            else if (nl.includes(lower)) {
                subs.push(entry);
            }
        }
        if (exacts.length === 0 && subs.length === 0) {
            for (const entry of this._nodeFlatIndex) {
                if ((0, levenshtein_1.levenshtein)(lower, entry.name.toLowerCase(), 2) <= 2) {
                    fuzzy.push(entry);
                }
            }
        }
        const sortFn = (a, b) => b.childCount - a.childCount;
        exacts.sort(sortFn);
        subs.sort(sortFn);
        fuzzy.sort(sortFn);
        const combined = [...exacts, ...subs, ...fuzzy];
        if (combined.length > max) {
            process.stderr.write(`[comdr] document fuzzy search truncated: ${combined.length} → ${max} results for "${query}"\n`);
        }
        return combined.slice(0, max).map((e) => ({
            name: e.name, fileId: e.fileId, path: e.path, childCount: e.childCount, compTypes: e.compTypes,
        }));
    }
    // ===== 索引维护 =====
    /** 重建 flat 索引 + 节点级 fileId 索引 */
    rebuildFlatIndex(prebuilt, nodeIdIndex) {
        if (prebuilt) {
            this._nodeFlatIndex = prebuilt;
            if (nodeIdIndex)
                this._nodeIdIndex = nodeIdIndex;
            return;
        }
        // 无预构建数据时不做回退——Document 侧通过 _buildTree 保证有数据传入
    }
    /** _json 变异后使惰性索引失效 */
    _invalidateCaches() {
        this._prefabInfoIndex = null;
        this._compToCpiIndex = null;
    }
    _ensurePrefabInfoIndex() {
        if (this._prefabInfoIndex !== null)
            return;
        this._prefabInfoIndex = new Map();
        for (let i = 0; i < this._json.length; i++) {
            const obj = this._json[i];
            if (obj && !obj.__deleted__ && obj.__type__ === 'cc.PrefabInfo' && obj.fileId) {
                this._prefabInfoIndex.set(obj.fileId, i);
            }
        }
    }
    _ensureCompToCpiIndex() {
        if (this._compToCpiIndex !== null)
            return;
        this._compToCpiIndex = new Map();
        for (let j = 0; j < this._json.length; j++) {
            const compObj = this._json[j];
            if (compObj && !compObj.__deleted__) {
                const cpiRef = compObj.__prefab;
                if (cpiRef?.__id__ != null) {
                    this._compToCpiIndex.set(cpiRef.__id__, j);
                }
            }
        }
    }
}
exports.NodeResolver = NodeResolver;
//# sourceMappingURL=node-resolver.js.map