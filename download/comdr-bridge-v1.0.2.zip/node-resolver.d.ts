export interface CocosObject {
    __type__?: string;
    __id__?: number;
    __uuid__?: string;
    __deleted__?: boolean;
    _name?: string;
    _objFlags?: number;
    _children?: Array<{
        __id__: number;
    }>;
    _components?: Array<{
        __id__: number;
    }>;
    _prefab?: {
        __id__: number;
    };
    _parent?: {
        __id__: number;
    } | null;
    _active?: boolean;
    _enabled?: boolean;
    _id?: string;
    node?: {
        __id__: number;
    };
    fileId?: string;
    data?: {
        __id__: number;
    };
    root?: {
        __id__: number;
    };
    asset?: null | {
        __uuid__: string;
    };
    sync?: boolean;
    [key: string]: unknown;
}
export interface FindNodeResult {
    nodeObj: CocosObject;
    nodeIndex: number;
    prefabInfo: CocosObject;
    prefabInfoIndex: number;
}
export interface FindComponentResult {
    compObj: CocosObject;
    compIndex: number;
    compPrefabInfo: CocosObject;
    compPrefabInfoIndex: number;
    fileId: string;
}
export interface FlatIndexEntry {
    name: string;
    fileId: string;
    path: string;
    compTypes: string[];
    childCount: number;
}
export declare class NodeResolver {
    private _json;
    _nodeFlatIndex: FlatIndexEntry[];
    _nodeIdIndex: Map<string, number> | null;
    private _prefabInfoIndex;
    private _compToCpiIndex;
    constructor(json: CocosObject[]);
    /** JSON 引用更新时调用（edit 后 _json 可能被替换） */
    updateJson(json: CocosObject[]): void;
    findNode(fileId: string): FindNodeResult | null;
    findComponent(fileId: string): FindComponentResult | null;
    findComponentByType(nodeFileId: string, componentType: string): FindComponentResult | null;
    /** 统一节点引用解析入口。
     *  接受 #fileId / 路径 / 模糊名，返回 FindNodeResult 或错误。 */
    resolveNodeRef(ref: string): FindNodeResult | {
        ok: false;
        error: string;
        code: string;
        matches?: Array<{
            name: string;
            path: string;
            fileId: string;
        }>;
    };
    /** 模糊名匹配引擎 */
    private _fuzzyMatchNames;
    /** 重建 flat 索引 + 节点级 fileId 索引 */
    rebuildFlatIndex(prebuilt?: FlatIndexEntry[], nodeIdIndex?: Map<string, number>): void;
    /** _json 变异后使惰性索引失效 */
    private _invalidateCaches;
    private _ensurePrefabInfoIndex;
    private _ensureCompToCpiIndex;
}
//# sourceMappingURL=node-resolver.d.ts.map