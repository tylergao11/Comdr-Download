import { Document } from './document';
import type { ResourceIndex } from './resource-index';
export type ProbeKind = 'project-summary' | 'assets' | 'asset' | 'asset-search' | 'document-serialize' | 'schema' | 'scripts' | 'console' | 'property';
export interface ProbeRequest {
    kind: ProbeKind;
    path?: string;
    paths?: string[];
    pattern?: string;
    name?: string;
    fileId?: string;
    componentType?: string;
    property?: string;
    level?: string;
    limit?: number;
    query?: string;
    [key: string]: unknown;
}
export interface ProbeResponse {
    ok: boolean;
    kind: ProbeKind;
    error?: string;
    errorCode?: string;
    data?: Record<string, unknown>;
}
export declare class ProbeV2 {
    private _projectPath;
    private _assetsDir;
    private _currentDoc;
    private _openDocs;
    private _resourceIndex;
    /** 注入 ResourceIndex（由 index.ts 在初始化后调用） */
    setResourceIndex(ri: ResourceIndex): void;
    constructor(projectPath: string, currentDoc?: Document | null, openDocs?: Map<string, Document> | null);
    setDocument(doc: Document | null): void;
    /** 统一探针入口 */
    handle(request: ProbeRequest): Promise<ProbeResponse>;
    private projectSummary;
    private listAssets;
    private resolveAsset;
    private searchAssets;
    private serializeDocument;
    private getSchema;
    private listScripts;
    private getConsoleLogs;
    private readProperty;
    /** 读取 .meta 文件，返回 { uuid, importer, subMetas } 或 null */
    private _readMetaFile;
    private safeDir;
    private static _walkDirCache;
    private static _WALKDIR_CACHE_MAX;
    private walkDir;
    private fuzzyAssetSearch;
}
//# sourceMappingURL=probe-v2.d.ts.map