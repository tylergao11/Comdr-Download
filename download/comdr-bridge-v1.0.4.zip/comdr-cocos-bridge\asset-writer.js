"use strict";
// ============================================================
// AssetWriter — 资产写入处理器
// ============================================================
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.AssetWriter = void 0;
exports.copyFileOrFolder = copyFileOrFolder;
exports.remapRefs = remapRefs;
// ── 镜像 foundation 常量（bridge 独立部署不能 import）──
const EXT_SCENE = '.scene'; // → foundation/constants.ts
const EXT_META = '.meta'; // → foundation/constants.ts
const fs = __importStar(require("fs"));
const path = __importStar(require("path"));
const path_utils_1 = require("./path-utils");
const id_utils_1 = require("./id-utils");
const fs_utils_1 = require("./fs-utils");
class AssetWriter {
    _projectPath;
    constructor(projectPath) {
        this._projectPath = projectPath;
    }
    async writeAsset(payload, skipRefresh) {
        const rawPath = (payload.path || payload.dbUrl);
        const json = payload.json;
        // 从扩展名推断资产类型，Gateway 也可显式指定 payload.assetType 覆盖
        const assetType = payload.assetType || (rawPath.endsWith(EXT_SCENE) ? 'scene' : 'prefab');
        const overwrite = !!payload.overwrite;
        if (!rawPath || !json) {
            return { ok: false, error: 'Missing path or json data' };
        }
        // Normalize: strip db://, ensure assets/ prefix, normalize slashes
        const normalized = (0, path_utils_1.normalizeAssetPath)(rawPath);
        let assetPath = normalized.fsPath;
        // 创建新文件时防同名；覆盖模式直接写
        if (!overwrite) {
            const resolved = resolveWritePath(this._projectPath, assetPath);
            if (!resolved) {
                return { ok: false, error: `Too many name conflicts for ${assetPath} (${MAX_RENAME_ATTEMPTS} attempts exhausted)` };
            }
            assetPath = resolved;
        }
        const fullPath = path.resolve(this._projectPath, assetPath);
        // 确保目录存在
        const dir = path.dirname(fullPath);
        fs.mkdirSync(dir, { recursive: true });
        // 原子写入：先写 tmp 再 rename，防止进程崩溃损坏源文件
        (0, fs_utils_1.writeFileAtomic)(fullPath, JSON.stringify(json, null, 2) + '\n');
        // 写入 .meta 文件（如果不存在）
        const metaPath = fullPath + EXT_META;
        if (!fs.existsSync(metaPath)) {
            const meta = this._generateMeta(assetType, assetPath);
            fs.writeFileSync(metaPath, JSON.stringify(meta, null, 2) + '\n', 'utf8');
        }
        // 通知编辑器刷新
        if (!skipRefresh) {
            try {
                await Editor.Message.request('asset-db', 'refresh-asset', fullPath);
            }
            catch (e) {
                console.warn(`[comdr] Editor refresh after write failed: ${(e instanceof Error ? e.message : String(e))}`);
            }
        }
        // 验证写回
        const verified = this._verifyWriteback(fullPath, json);
        return {
            ok: true,
            path: assetPath,
            fullPath,
            verified,
        };
    }
    _verifyWriteback(filePath, expected) {
        try {
            const raw = fs.readFileSync(filePath, 'utf8').replace(/^﻿/, '');
            const actual = JSON.parse(raw);
            if (!Array.isArray(actual)) {
                return { ok: false, issue: 'Not a JSON array' };
            }
            if (!Array.isArray(expected)) {
                return { ok: false, issue: 'Expected value is not an array' };
            }
            const expectedArr = expected;
            const actualArr = actual;
            // 类型分布对比（cc.Node, cc.PrefabInfo, cc.CompPrefabInfo 等关键类型计数）
            const countByType = (arr) => {
                const counts = {};
                for (const item of arr) {
                    const t = item?.__type__ || '(none)';
                    counts[t] = (counts[t] || 0) + 1;
                }
                return counts;
            };
            const expectedTypes = countByType(expectedArr);
            const actualTypes = countByType(actualArr);
            // 类型分布不一致的项
            const mismatchedTypes = {};
            const allTypes = new Set([...Object.keys(expectedTypes), ...Object.keys(actualTypes)]);
            for (const t of allTypes) {
                const e = expectedTypes[t] || 0;
                const a = actualTypes[t] || 0;
                if (e !== a)
                    mismatchedTypes[t] = { expected: e, actual: a };
            }
            return {
                ok: Object.keys(mismatchedTypes).length === 0,
                expectedCount: expectedArr.length,
                actualCount: actualArr.length,
                expectedNodes: expectedTypes['cc.Node'] || 0,
                actualNodes: actualTypes['cc.Node'] || 0,
                ...(Object.keys(mismatchedTypes).length > 0 ? { mismatchedTypes } : {}),
            };
        }
        catch (err) {
            return { ok: false, issue: err instanceof Error ? err.message : String(err) };
        }
    }
    _generateMeta(assetType, assetPath) {
        const uuid = (0, id_utils_1.generateUuid)();
        return {
            ver: '1.1.0',
            importer: assetType === 'scene' ? 'scene' : 'prefab',
            imported: true,
            uuid,
            files: [path.basename(assetPath)],
            subMetas: {},
            userData: { comdr: { createdAt: new Date().toISOString() } },
        };
    }
}
exports.AssetWriter = AssetWriter;
// ===== 文件拷贝 =====
// 镜像 document.ts 常量（bridge 独立部署，修改时两边同步）
const NODE_LIKE_TYPES = new Set(['cc.Node', 'cc.Scene']);
const FILEID_TYPES = new Set(['cc.PrefabInfo', 'cc.CompPrefabInfo', 'cc.PrefabInstance', 'cc.PropertyOverrideInfo', 'cc.TargetInfo']);
const EXT_SCENE_PREFAB_RE = /\.(scene|prefab)$/;
const MAX_RENAME_ATTEMPTS = 1000;
/** 防同名：在 projectPath 下为 assetRelPath 找到不冲突的路径。
 *  与 writeAsset 逻辑一致：检查文件 + .meta，冲突时加 _1 _2 后缀。 */
function resolveWritePath(projectPath, assetRelPath) {
    const original = assetRelPath.replace(/\/$/, '');
    let result = original;
    let counter = 0;
    while (counter < MAX_RENAME_ATTEMPTS) {
        const check = path.join(projectPath, result);
        if (!fs.existsSync(check) && !fs.existsSync(check + EXT_META))
            return result;
        counter++;
        const dot = original.lastIndexOf('.');
        result = dot > 0
            ? original.slice(0, dot) + '_' + counter + original.slice(dot)
            : original + '_' + counter;
    }
    return null; // >1000 conflicts
}
/** 文件级 ID 重生成：覆盖所有含 _id / fileId 的对象类型。
 *  比 document.ts 的 regenerateCloneIds 多处理 PrefabInstance/PropertyOverrideInfo/TargetInfo。
 *  拷贝后两文件独立，__id__ 和 __uuid__ 保持不变。 */
function regenerateInternalIds(json) {
    for (const obj of json) {
        const type = obj.__type__;
        if (type && FILEID_TYPES.has(type)) {
            obj.fileId = (0, id_utils_1.generateFileId)();
        }
        if (type && NODE_LIKE_TYPES.has(type)) {
            obj._id = (0, id_utils_1.generateFileId)();
        }
    }
}
/** 拷贝单个 .scene/.prefab：读 → clone → 重生成 ID → 写回（走 AssetWriter 防同名）。
 *  skipResolve 为 true 时跳过文件夹层面已做过的防同名检查。 */
async function copySingleFileAsset(projectPath, fullSource, destRelPath, skipRefresh, skipResolve) {
    let raw;
    try {
        raw = fs.readFileSync(fullSource, 'utf8');
    }
    catch (e) {
        return { ok: false, error: `Failed to read source: ${e.message}` };
    }
    let json;
    try {
        json = JSON.parse(raw);
    }
    catch (e) {
        return { ok: false, error: `Invalid JSON in source: ${e.message}` };
    }
    if (!Array.isArray(json))
        return { ok: false, error: `Not a valid scene/prefab JSON: ${destRelPath}` };
    const cloned = JSON.parse(JSON.stringify(json));
    regenerateInternalIds(cloned);
    const writer = new AssetWriter(projectPath);
    // skipResolve → overwrite: true，跳过 writeAsset 内部的防同名逻辑
    return writer.writeAsset({ path: destRelPath, json: cloned, overwrite: skipResolve }, skipRefresh);
}
/** 拷贝非 scene/prefab 文件：字节拷贝 + 读旧 .meta → 换 UUID → 写新 .meta。
 *  skipResolve 为 true 时跳过文件夹层面已做过的防同名检查。 */
async function copyRawAsset(projectPath, fullSource, destRelPath, skipRefresh, skipResolve) {
    // 防同名（文件夹 copy 已在目录级做过，无需重复）
    const resolved = skipResolve ? destRelPath : resolveWritePath(projectPath, destRelPath);
    if (!resolved)
        return { ok: false, error: `Too many name conflicts for ${destRelPath}` };
    const fullDest = path.join(projectPath, resolved);
    const dir = path.dirname(fullDest);
    fs.mkdirSync(dir, { recursive: true });
    // 字节拷贝
    try {
        fs.copyFileSync(fullSource, fullDest);
    }
    catch (e) {
        return { ok: false, error: `Failed to copy file: ${e.message}` };
    }
    // .meta 拷贝（换新 UUID）
    const srcMetaPath = fullSource + EXT_META;
    const destMetaPath = fullDest + EXT_META;
    if (fs.existsSync(srcMetaPath)) {
        try {
            const srcMeta = JSON.parse(fs.readFileSync(srcMetaPath, 'utf8'));
            srcMeta.uuid = (0, id_utils_1.generateUuid)();
            fs.writeFileSync(destMetaPath, JSON.stringify(srcMeta, null, 2) + '\n', 'utf8');
        }
        catch (e) {
            // .meta 损坏 → 生一个新的，不阻塞拷贝
            const ext = path.extname(resolved);
            const assetType = ext === '.scene' ? 'scene' : ext === '.prefab' ? 'prefab' : undefined;
            const newMeta = { ver: '1.1.0', importer: assetType || 'unknown', imported: true, uuid: (0, id_utils_1.generateUuid)(), files: [path.basename(resolved)], subMetas: {}, userData: {} };
            fs.writeFileSync(destMetaPath, JSON.stringify(newMeta, null, 2) + '\n', 'utf8');
        }
    }
    else {
        // 源没有 .meta → 生成新的
        const newMeta = { ver: '1.1.0', importer: 'unknown', imported: true, uuid: (0, id_utils_1.generateUuid)(), files: [path.basename(resolved)], subMetas: {}, userData: {} };
        fs.writeFileSync(destMetaPath, JSON.stringify(newMeta, null, 2) + '\n', 'utf8');
    }
    if (!skipRefresh) {
        try {
            await Editor.Message.request('asset-db', 'refresh-asset', fullDest);
        }
        catch { /* ok */ }
    }
    return { ok: true, path: resolved };
}
/** 模糊匹配：在项目 assets/ 下找同名文件或文件夹 */
function _fuzzyFind(projectPath, name) {
    const result = [];
    const assetsDir = path.join(projectPath, 'assets');
    const queue = [assetsDir];
    while (queue.length > 0) {
        const current = queue.shift();
        let entries;
        try {
            entries = fs.readdirSync(current, { withFileTypes: true });
        }
        catch {
            continue;
        }
        for (const entry of entries) {
            if (entry.name.startsWith('.') || entry.name === 'node_modules')
                continue;
            const full = path.join(current, entry.name);
            if (entry.name === name) {
                result.push(path.relative(assetsDir, full).replace(/\\/g, '/'));
            }
            if (entry.isDirectory())
                queue.push(full);
        }
    }
    return result;
}
/** 递归收集目录下所有非 .meta 文件路径 */
function _collectFiles(dir) {
    const result = [];
    const queue = [dir];
    while (queue.length > 0) {
        const current = queue.shift();
        let entries;
        try {
            entries = fs.readdirSync(current, { withFileTypes: true });
        }
        catch {
            continue;
        }
        for (const entry of entries) {
            const full = path.join(current, entry.name);
            if (entry.isDirectory()) {
                queue.push(full);
            }
            else if (!entry.name.endsWith(EXT_META)) {
                result.push(full);
            }
        }
    }
    return result;
}
/** 单文件拷贝入口：scene/prefab → ID 重生成，其他 → 原样字节拷贝 */
async function copySingleAsset(projectPath, fullSource, destRelPath, skipRefresh, skipResolve) {
    if (EXT_SCENE_PREFAB_RE.test(path.extname(destRelPath))) {
        return copySingleFileAsset(projectPath, fullSource, destRelPath, skipRefresh, skipResolve);
    }
    return copyRawAsset(projectPath, fullSource, destRelPath, skipRefresh, skipResolve);
}
/** 拷贝文件或文件夹。文件系统直判类型，不限文件格式。
 *  destPath 可选: 指定目标路径（跳过自动 _1 防同名） */
async function copyFileOrFolder(projectPath, sourcePath, destPath) {
    const normalized = (0, path_utils_1.normalizeAssetPath)(sourcePath);
    // 容错：尾斜杠去掉（Commander 写路径时常多带）
    normalized.fsPath = normalized.fsPath.replace(/\/+$/, '');
    const fullSource = path.join(projectPath, normalized.fsPath);
    if (!fs.existsSync(fullSource)) {
        const name = path.basename(normalized.fsPath);
        const found = _fuzzyFind(projectPath, name);
        const hint = found.length > 0
            ? ` Did you mean: ${found.slice(0, 3).join(', ')}${found.length > 3 ? '...' : ''}`
            : '';
        return { ok: false, error: `Source not found: ${normalized.fsPath}.${hint}` };
    }
    const stat = fs.statSync(fullSource);
    // ── 目录 ──
    if (stat.isDirectory()) {
        const targetDir = destPath
            ? (0, path_utils_1.normalizeAssetPath)(destPath).fsPath
            : normalized.fsPath;
        const destDir = resolveWritePath(projectPath, targetDir);
        if (!destDir)
            return { ok: false, error: `Too many name conflicts for directory: ${targetDir}` };
        const files = _collectFiles(fullSource);
        if (files.length === 0)
            return { ok: false, error: `Directory is empty: ${normalized.fsPath}` };
        // 全并发拷贝：文件夹已防同名，内部文件直接写（不再走 resolveWritePath 防同名）
        const settled = await Promise.allSettled(files.map(async (file) => {
            const rel = path.relative(fullSource, file).replace(/\\/g, '/');
            const destRel = destDir.replace(/\/?$/, '/') + rel;
            return copySingleAsset(projectPath, file, destRel, true /* skipRefresh */, true /* skipResolve */);
        }));
        const results = settled.map((s) => s.status === 'fulfilled' ? s.value : { ok: false, error: String(s.reason) });
        // 一次目录级刷新替代 N 次单文件刷新
        try {
            await Editor.Message.request('asset-db', 'refresh-asset', path.join(projectPath, destDir));
        }
        catch { /* ok */ }
        const okCount = results.filter((r) => r.ok !== false).length;
        const failCount = results.length - okCount;
        return { ok: failCount === 0, data: { kind: 'folder', count: results.length, okCount, failCount, dir: destDir, results } };
    }
    // ── 文件 ──
    const dest = destPath
        ? (0, path_utils_1.normalizeAssetPath)(destPath).fsPath
        : normalized.fsPath;
    const result = await copySingleAsset(projectPath, fullSource, dest);
    return { ok: result.ok !== false, data: { kind: 'file', ...result } };
}
// ===== UUID 引用重定向 =====
/** 从 .meta 文件中提取 UUID。失败时返回 null + stderr 诊断区分原因。 */
function _metaUuid(metaPath) {
    try {
        const meta = JSON.parse(fs.readFileSync(metaPath, 'utf8'));
        return meta.uuid || null;
    }
    catch (e) {
        const code = e?.code;
        if (code !== 'ENOENT') {
            process.stderr.write(`[comdr] _metaUuid failed (${metaPath}): ${e instanceof Error ? e.message : String(e)}\n`);
        }
        return null;
    }
}
/** 扫目录下所有 .meta → { 相对路径: uuid } */
function _scanMetaUuids(dir) {
    const result = {};
    const files = _collectFiles(dir);
    for (const f of files) {
        const uuid = _metaUuid(f + EXT_META);
        if (uuid) {
            const rel = path.relative(dir, f).replace(/\\/g, '/');
            result[rel] = uuid;
        }
    }
    return result;
}
/** 从路径提取 UUID：文件存在 → 读 .meta，不存在 → basename 当裸 UUID */
function _resolveUuid(fullPath) {
    if (fs.existsSync(fullPath))
        return _metaUuid(fullPath + EXT_META);
    // 不是文件路径 → basename 当裸 UUID
    const name = path.basename(fullPath);
    return name || null;
}
/** 宽松检查字符串是否像 UUID（含连字符的十六进制，或 Cocos 压缩短格式） */
function _looksLikeUuid(s) {
    // Cocos UUID 标准格式：xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx
    // 压缩格式：去掉连字符的 hex 串（通常 20-32 位）
    const hexOnly = s.replace(/-/g, '');
    return hexOnly.length >= 20 && /^[0-9a-f]+$/i.test(hexOnly);
}
/** 构建 old → new UUID 映射表。
 *  from/to 可以是文件路径、文件夹路径、或裸 UUID 字符串 */
function _buildUuidMap(fromPath, toPath) {
    // 文件系统路径不存在 → 裸 UUID 模式。
    // 防御：basename 不像 UUID 则回退空映射（避免误把文件名当 UUID 做全文件正则扫描）。
    if (!fs.existsSync(fromPath)) {
        const oldUuid = path.basename(fromPath);
        if (!_looksLikeUuid(oldUuid)) {
            process.stderr.write(`[comdr] remap-refs: from path not found and basename "${oldUuid}" does not look like a UUID — skipped.\n`);
            return {};
        }
        const newUuid = _resolveUuid(toPath);
        if (newUuid && !_looksLikeUuid(newUuid)) {
            process.stderr.write(`[comdr] remap-refs: to path not found and basename "${newUuid}" does not look like a UUID — skipped.\n`);
            return {};
        }
        return (oldUuid && newUuid && oldUuid !== newUuid) ? { [oldUuid]: newUuid } : {};
    }
    const fromIsDir = fs.statSync(fromPath).isDirectory();
    const map = {};
    if (fromIsDir) {
        const fromUuids = _scanMetaUuids(fromPath);
        const toUuids = _scanMetaUuids(toPath);
        for (const [rel, oldUuid] of Object.entries(fromUuids)) {
            const newUuid = toUuids[rel];
            if (newUuid && newUuid !== oldUuid) {
                map[oldUuid] = newUuid;
            }
        }
    }
    else {
        const oldUuid = _metaUuid(fromPath + EXT_META);
        const newUuid = _resolveUuid(toPath);
        if (oldUuid && newUuid && oldUuid !== newUuid) {
            map[oldUuid] = newUuid;
        }
    }
    return map;
}
/** 对单个文件执行 UUID 替换（完整格式 + Cocos 压缩格式，字符串级） */
function _remapFileUuids(filePath, uuidMap) {
    let raw;
    try {
        raw = fs.readFileSync(filePath, 'utf8');
    }
    catch (e) {
        process.stderr.write(`[comdr] remap-refs: failed to read ${filePath}: ${e instanceof Error ? e.message : String(e)}\n`);
        return 0;
    }
    let replaced = 0;
    for (const [oldUuid, newUuid] of Object.entries(uuidMap)) {
        // 完整 UUID（含连字符）
        const escapedFull = oldUuid.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
        const reFull = new RegExp(escapedFull, 'g');
        const matchesFull = (raw.match(reFull) || []).length;
        if (matchesFull > 0) {
            raw = raw.replace(reFull, newUuid);
            replaced += matchesFull;
        }
        // Cocos 压缩 UUID（__type__ 中使用的 23 字符格式）
        const oldCompressed = (0, id_utils_1.compressUuid)(oldUuid);
        const newCompressed = (0, id_utils_1.compressUuid)(newUuid);
        if (oldCompressed !== oldUuid && oldCompressed !== newCompressed) {
            const escapedCmp = oldCompressed.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
            const reCmp = new RegExp(escapedCmp, 'g');
            const matchesCmp = (raw.match(reCmp) || []).length;
            if (matchesCmp > 0) {
                raw = raw.replace(reCmp, newCompressed);
                replaced += matchesCmp;
            }
        }
    }
    if (replaced > 0) {
        (0, fs_utils_1.writeFileAtomic)(filePath, raw);
    }
    return replaced;
}
/** 对 .ts 文件执行 import 路径替换（from/to 文件夹模式自动推导同相对路径下改名映射） */
function _remapFileImports(filePath, pathMap) {
    let raw;
    try {
        raw = fs.readFileSync(filePath, 'utf8');
    }
    catch {
        process.stderr.write(`[comdr] asset-writer: _remapFileImports failed to read ${filePath}\n`);
        return 0;
    }
    let replaced = 0;
    for (const [oldName, newName] of Object.entries(pathMap)) {
        const escaped = oldName.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
        // 匹配 import/export 路径末尾的文件名（不含扩展名）— from ".../OldName" 等
        const re = new RegExp(`((?:from|import)\\s+["'][^"']*\\/)${escaped}(["'])`, 'g');
        const newRaw = raw.replace(re, `$1${newName}$2`);
        if (newRaw !== raw) {
            const count = (raw.match(re) || []).length;
            replaced += count;
            raw = newRaw;
        }
    }
    if (replaced > 0) {
        (0, fs_utils_1.writeFileAtomic)(filePath, raw);
    }
    return replaced;
}
/** 从 from/to 文件夹对比，构建 import 路径映射（仅对同相对路径下改名的 .ts 文件） */
function _buildImportPathMap(fromDir, toDir) {
    const map = {};
    if (!fs.existsSync(fromDir) || !fs.statSync(fromDir).isDirectory())
        return map;
    if (!fs.existsSync(toDir) || !fs.statSync(toDir).isDirectory())
        return map;
    const fromFiles = _collectFiles(fromDir).filter((f) => f.endsWith('.ts'));
    for (const fromFile of fromFiles) {
        const rel = path.relative(fromDir, fromFile).replace(/\\/g, '/');
        const toFile = path.join(toDir, rel);
        // 同相对路径下 from 和 to 文件名不同 → 需要映射
        const fromBase = path.basename(fromFile, '.ts');
        const toBase = fs.existsSync(toFile) ? path.basename(toFile, '.ts') : null;
        if (toBase && fromBase !== toBase) {
            map[fromBase] = toBase;
        }
    }
    return map;
}
/** remap-refs — 将 target 中所有匹配 from→to 的 __uuid__ 引用替换
 *
 *  from/to 可以是单个文件或文件夹。
 *  文件夹模式：同相对路径配对 oldUuid→newUuid。
 *  target 可以是单个文件或文件夹。
 *  不限文件类型 — 有 .meta 即处理。
 */
async function remapRefs(projectPath, targetPath, fromPath, toPath) {
    const normTarget = (0, path_utils_1.normalizeAssetPath)(targetPath);
    const normFrom = (0, path_utils_1.normalizeAssetPath)(fromPath);
    const normTo = (0, path_utils_1.normalizeAssetPath)(toPath);
    const fullFrom = path.join(projectPath, normFrom.fsPath);
    const fullTo = path.join(projectPath, normTo.fsPath);
    const fullTarget = path.join(projectPath, normTarget.fsPath);
    if (!fs.existsSync(fullTarget))
        return { ok: false, error: `Target not found: ${normTarget.fsPath}` };
    // 建 UUID 映射表
    const uuidMap = _buildUuidMap(fullFrom, fullTo);
    // 建 import 路径映射表（文件夹模式）
    const fromIsDir = fs.existsSync(fullFrom) && fs.statSync(fullFrom).isDirectory();
    const toIsDir = fs.existsSync(fullTo) && fs.statSync(fullTo).isDirectory();
    const importPathMap = (fromIsDir && toIsDir)
        ? _buildImportPathMap(fullFrom, fullTo)
        : {};
    // 两表都空才是真的没东西可重定向
    if (Object.keys(uuidMap).length === 0 && Object.keys(importPathMap).length === 0) {
        return { ok: false, error: 'No mappings found — from and to share no matching relative paths' };
    }
    // 执行替换
    const targetIsDir = fs.statSync(fullTarget).isDirectory();
    let totalReplaced = 0;
    let totalImportReplaced = 0;
    const details = {};
    // UUID 替换
    if (Object.keys(uuidMap).length > 0) {
        if (targetIsDir) {
            const files = _collectFiles(fullTarget);
            const settled = await Promise.allSettled(files.map((f) => _remapFileUuids(f, uuidMap)));
            for (let i = 0; i < files.length; i++) {
                const s = settled[i];
                if (s.status === 'fulfilled' && s.value > 0) {
                    const rel = path.relative(fullTarget, files[i]).replace(/\\/g, '/');
                    details[rel] = (details[rel] || 0) + s.value;
                    totalReplaced += s.value;
                }
            }
        }
        else {
            const replaced = _remapFileUuids(fullTarget, uuidMap);
            if (replaced > 0) {
                details[normTarget.fsPath] = replaced;
                totalReplaced += replaced;
            }
        }
    }
    // import 路径重映射
    if (Object.keys(importPathMap).length > 0) {
        const tsFiles = _collectFiles(fullTarget).filter((f) => f.endsWith('.ts'));
        const settled = await Promise.allSettled(tsFiles.map((f) => _remapFileImports(f, importPathMap)));
        for (let i = 0; i < tsFiles.length; i++) {
            const s = settled[i];
            if (s.status === 'fulfilled' && s.value > 0) {
                const rel = path.relative(fullTarget, tsFiles[i]).replace(/\\/g, '/');
                details[rel] = (details[rel] || 0) + s.value;
                totalImportReplaced += s.value;
            }
        }
    }
    // 一次目录级 refresh 替代 N 次单文件 refresh
    if (targetIsDir && (totalReplaced > 0 || totalImportReplaced > 0)) {
        try {
            await Editor.Message.request('asset-db', 'refresh-asset', fullTarget);
        }
        catch { /* */ }
    }
    else if (!targetIsDir && totalReplaced > 0) {
        try {
            await Editor.Message.request('asset-db', 'refresh-asset', fullTarget);
        }
        catch { /* */ }
    }
    return {
        ok: true,
        data: {
            mappings: Object.keys(uuidMap).length,
            replaced: totalReplaced,
            importReplaced: totalImportReplaced,
            details,
        },
    };
}
//# sourceMappingURL=asset-writer.js.map