"use strict";
// ============================================================
// ProbeV2 — 统一的 Bridge 探针入口
// 替代 asset-probe.ts 的 14 分支 switch。
// 统一请求形状 → 统一响应形状。一个入口，一种规则。
// ============================================================
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.ProbeV2 = void 0;
const fs = __importStar(require("fs"));
const path = __importStar(require("path"));
const document_1 = require("./document");
// ── 镜像 foundation 常量 ──
const ENV_COMDR_DIAG = 'COMDR_DIAG';
const path_utils_1 = require("./path-utils");
const error_codes_1 = require("./error-codes");
const levenshtein_1 = require("./utils/levenshtein");
// ── 镜像 foundation 常量（bridge 独立部署不能 import，修改时必须两边同步）──
// EXT_SCENE / EXT_PREFAB / EXT_TS / EXT_JS / EXT_META → foundation/constants.ts
const EXT_SCENE = '.scene';
const EXT_PREFAB = '.prefab';
const EXT_TS = '.ts';
const EXT_JS = '.js';
const EXT_META = '.meta';
// COMDR_TEMP_DIR → foundation/constants.ts
const COMDR_TEMP = 'temp/comdr';
// ===== 统一入口 =====
class ProbeV2 {
    _projectPath;
    _assetsDir;
    _currentDoc;
    _openDocs;
    _resourceIndex = null;
    /** 注入 ResourceIndex（由 index.ts 在初始化后调用） */
    setResourceIndex(ri) { this._resourceIndex = ri; }
    constructor(projectPath, currentDoc = null, openDocs) {
        this._projectPath = projectPath;
        this._assetsDir = path.join(projectPath, 'assets');
        this._currentDoc = currentDoc;
        this._openDocs = openDocs || null;
    }
    setDocument(doc) {
        this._currentDoc = doc;
    }
    /** 统一探针入口 */
    async handle(request) {
        switch (request.kind) {
            case 'project-summary': return this.projectSummary();
            case 'assets': return this.listAssets(request.path);
            case 'asset': return this.resolveAsset(request.path || '');
            case 'asset-search': return this.searchAssets(request.pattern || request.query || '');
            case 'document-serialize': return this.serializeDocument(request.path);
            case 'schema': return this.getSchema(request.componentType || '');
            case 'scripts': return this.listScripts(request.path);
            case 'console': return this.getConsoleLogs(request.level, request.limit);
            case 'property': return this.readProperty(request.fileId || '', request.componentType || '', request.property);
            default:
                return { ok: false, kind: request.kind, error: `Unknown probe kind: ${request.kind}` };
        }
    }
    // ===== 各探针实现 =====
    async projectSummary() {
        const allFiles = this.walkDir(this._assetsDir);
        const scenes = allFiles.filter((f) => f.endsWith(EXT_SCENE)).length;
        const prefabs = allFiles.filter((f) => f.endsWith(EXT_PREFAB)).length;
        const tsFiles = allFiles.filter((f) => f.endsWith(EXT_TS) || f.endsWith(EXT_JS));
        const scripts = tsFiles.length;
        // 提取脚本类名
        const scriptList = [];
        for (const f of tsFiles) {
            const relPath = path.relative(this._assetsDir, f).replace(/\\/g, '/');
            // 尝试读 .meta 获取 UUID
            let uuid = '';
            try {
                const meta = JSON.parse(fs.readFileSync(f + '.meta', 'utf8'));
                uuid = meta.uuid || '';
            }
            catch {
                process.stderr.write(`[comdr] probe-v2: failed to read .meta, uuid may be empty\n`);
            }
            // 提取可能的类名（从文件名）
            const name = path.basename(f, path.extname(f));
            scriptList.push({ name, path: relPath, compressedId: uuid });
        }
        return {
            ok: true,
            kind: 'project-summary',
            data: {
                kind: 'project-summary',
                scenes,
                prefabs,
                scripts,
                scriptList,
            },
        };
    }
    async listAssets(subPath) {
        if (subPath) {
            const target = this.safeDir(subPath);
            if (!target)
                return { ok: false, kind: 'assets', error: 'Invalid dir' };
            const files = this.walkDir(target)
                .filter((f) => !f.endsWith(EXT_META))
                .map((f) => ({
                name: path.basename(f),
                path: path.relative(this._assetsDir, f).replace(/\\/g, '/'),
                isDir: false,
            }));
            return { ok: true, kind: 'assets', data: { kind: 'assets', path: subPath, entries: files } };
        }
        // 无 path：全量递归扫描，供超图建图等需要完整项目库存的场景
        if (process.env[ENV_COMDR_DIAG])
            process.stderr.write('[comdr] listAssets FULL SCAN v2\n');
        const allFiles = this.walkDir(this._assetsDir);
        const entries = allFiles
            .filter((f) => !f.endsWith(EXT_META))
            .map((f) => {
            const rel = path.relative(this._assetsDir, f).replace(/\\/g, '/');
            const stat = fs.statSync(f);
            return {
                name: path.basename(f),
                path: rel,
                isDir: stat.isDirectory(),
            };
        });
        return { ok: true, kind: 'assets', data: { kind: 'assets', path: '', entries } };
    }
    async resolveAsset(assetPath) {
        if (!assetPath)
            return { ok: false, kind: 'asset', error: 'Missing path' };
        const normalized = (0, path_utils_1.normalizeAssetPath)(assetPath);
        // 1. asset-db API
        try {
            const result = await Editor.Message.request('asset-db', 'query-asset-info', normalized.dbUrl);
            if (result && typeof result === 'object' && !Array.isArray(result)) {
                const obj = result;
                return {
                    ok: true, kind: 'asset',
                    data: {
                        kind: 'asset', path: normalized.fsPath,
                        uuid: obj.uuid || '', importer: obj.importer || '',
                    },
                };
            }
        }
        catch {
            process.stderr.write('[comdr] probe-v2: MetaProbe result parse failed (fall through)\n');
        }
        // 2. .meta 文件直读
        const meta = this._readMetaFile(path.join(this._projectPath, normalized.fsPath));
        if (meta) {
            const subAssets = [];
            if (meta.subMetas) {
                for (const [key, val] of Object.entries(meta.subMetas)) {
                    subAssets.push({ name: key, uuid: val.uuid || '' });
                }
            }
            return {
                ok: true, kind: 'asset',
                data: {
                    kind: 'asset', path: normalized.fsPath,
                    uuid: meta.uuid, importer: meta.importer,
                    subAssets: subAssets.length > 0 ? subAssets : undefined,
                },
            };
        }
        // 3. 模糊搜索回退 — 多项匹配时不静默选一，返回候选列表
        const fuzzy = this.fuzzyAssetSearch(assetPath);
        if (fuzzy.length === 1) {
            return {
                ok: true, kind: 'asset',
                data: {
                    kind: 'asset', path: normalized.fsPath,
                    uuid: fuzzy[0].uuid, importer: '',
                },
            };
        }
        if (fuzzy.length > 1) {
            return {
                ok: true, kind: 'asset',
                data: {
                    kind: 'asset', path: normalized.fsPath,
                    candidates: fuzzy,
                },
            };
        }
        return { ok: false, kind: 'asset', error: `Asset not found: ${assetPath}` };
    }
    async searchAssets(pattern) {
        if (!pattern)
            return { ok: false, kind: 'asset-search', error: 'Missing pattern' };
        const lower = pattern.toLowerCase();
        const results = [];
        const MAX_SEARCH_DEPTH = 20;
        const searchDir = (dir, depth) => {
            if (depth > MAX_SEARCH_DEPTH)
                return;
            try {
                const entries = fs.readdirSync(dir, { withFileTypes: true });
                for (const entry of entries) {
                    const fullPath = path.join(dir, entry.name);
                    const rel = path.relative(this._assetsDir, fullPath).replace(/\\/g, '/');
                    if (entry.isDirectory() && !entry.name.startsWith('.')) {
                        if (entry.name.toLowerCase().includes(lower)) {
                            results.push({ name: entry.name, path: rel, isDir: true });
                        }
                        searchDir(fullPath, depth + 1);
                    }
                    else if (entry.name.toLowerCase().includes(lower)) {
                        results.push({ name: entry.name, path: rel, isDir: false });
                    }
                }
            }
            catch {
                process.stderr.write('[comdr] probe-v2: asset search dir scan failed (non-fatal)\n');
            }
        };
        searchDir(this._assetsDir, 0);
        return {
            ok: true, kind: 'asset-search',
            data: { kind: 'assets', path: '', entries: results },
        };
    }
    async serializeDocument(targetPath) {
        let doc = this._currentDoc;
        if (targetPath && this._openDocs) {
            const targetDoc = this._openDocs.get(targetPath);
            if (targetDoc)
                doc = targetDoc;
        }
        if (!doc)
            return { ok: false, kind: 'document-serialize', error: 'No open document' };
        try {
            // 从磁盘重读，确保返回真实文件状态（用户可能在编辑器中手动修改过）
            // 不改 _currentDoc — 保留内存中未保存的编辑，仅 probe 用磁盘副本
            const fresh = document_1.Document.open(this._projectPath, doc.dbUrl, doc.kind);
            const source = fresh.ok ? fresh.doc : doc;
            const json = JSON.parse(source.serialize());
            return {
                ok: true, kind: 'document-serialize',
                data: { kind: 'document', path: source.dbUrl || '', json, rootFileId: '', nodeCount: json.length },
            };
        }
        catch (e) {
            return { ok: false, kind: 'document-serialize', error: `Serialize failed: ${e instanceof Error ? e.message : String(e)}` };
        }
    }
    async getSchema(componentType) {
        if (!componentType)
            return { ok: false, kind: 'schema', error: 'Missing componentType' };
        // 安全：JSON.stringify 阻止任意代码注入，componentType 只能是字符串，无法突破引号边界。
        // require('./bridge-probe-lib') 依赖 Cocos Editor 的 scene 脚本执行环境的 cwd 为扩展目录。
        try {
            const scriptContent = `
        var probeLib = require('./bridge-probe-lib');
        probeLib(cc, EditorExtends).getComponentSchema(${JSON.stringify(componentType)});
      `;
            const result = await Editor.Message.request('scene', 'execute-scene-script', scriptContent);
            if (result && typeof result === 'object') {
                const obj = result;
                return {
                    ok: true, kind: 'schema',
                    data: {
                        kind: 'schema',
                        componentType,
                        isScript: !!obj.isScript,
                        className: obj.className,
                        properties: obj.properties || [],
                    },
                };
            }
            return { ok: false, kind: 'schema', error: 'Schema query returned no data' };
        }
        catch (e) {
            return { ok: false, kind: 'schema', error: `Schema probe failed: ${(e instanceof Error ? e.message : String(e))}` };
        }
    }
    async listScripts(subPath) {
        if (subPath) {
            const target = this.safeDir(subPath);
            if (!target)
                return { ok: false, kind: 'scripts', error: 'Invalid dir' };
            const files = this.walkDir(target)
                .filter((f) => f.endsWith(EXT_TS) || f.endsWith(EXT_JS))
                .map((f) => {
                const rel = path.relative(this._assetsDir, f).replace(/\\/g, '/');
                return { name: path.basename(f, path.extname(f)), path: rel, compressedId: '', methods: [], properties: [] };
            });
            return { ok: true, kind: 'scripts', data: { kind: 'scripts', path: subPath, scripts: files } };
        }
        // 全项目扫描：先触发 ResourceIndex 刷新（自动生成缺失 .meta）
        if (this._resourceIndex) {
            await this._resourceIndex.fullScan();
            const scripts = this._resourceIndex.getScripts().map((s) => ({
                name: s.name,
                path: path.relative(this._assetsDir, s.path).replace(/\\/g, '/'),
                compressedId: s.compressedId,
                methods: s.methods,
                properties: s.properties,
            }));
            return { ok: true, kind: 'scripts', data: { kind: 'scripts', path: '', scripts } };
        }
        // Fallback：ResourceIndex 未注入时内联扫描
        const files = this.walkDir(this._assetsDir)
            .filter((f) => f.endsWith(EXT_TS) || f.endsWith(EXT_JS))
            .map((f) => {
            const rel = path.relative(this._assetsDir, f).replace(/\\/g, '/');
            return { name: path.basename(f, path.extname(f)), path: rel, compressedId: '', methods: [], properties: [] };
        });
        return { ok: true, kind: 'scripts', data: { kind: 'scripts', path: '', scripts: files } };
    }
    async getConsoleLogs(level, limit) {
        try {
            const args = JSON.stringify({ level: level || undefined, limit, summary: !level });
            const scriptContent = `
        var probeLib = require('./bridge-probe-lib');
        probeLib(cc, EditorExtends).getConsoleLog(${args});
      `;
            const result = await Editor.Message.request('scene', 'execute-scene-script', scriptContent);
            return {
                ok: true, kind: 'console',
                data: { kind: 'console', entries: result || [] },
            };
        }
        catch (e) {
            return { ok: false, kind: 'console', error: `Console probe failed: ${(e instanceof Error ? e.message : String(e))}` };
        }
    }
    async readProperty(fileId, componentType, property) {
        if (!this._currentDoc)
            return { ok: false, kind: 'property', error: error_codes_1.MSG_NO_DOCUMENT_OPEN };
        const result = this._currentDoc.readProperty(fileId, componentType, property);
        return {
            ok: true, kind: 'property',
            data: {
                kind: 'property',
                fileId,
                componentType,
                property: property || '',
                value: result,
            },
        };
    }
    // ===== 工具方法 =====
    /** 读取 .meta 文件，返回 { uuid, importer, subMetas } 或 null */
    _readMetaFile(absPath) {
        try {
            const meta = JSON.parse(fs.readFileSync(absPath + '.meta', 'utf8'));
            return {
                uuid: meta.uuid || '',
                importer: meta.importer || '',
                subMetas: meta.subMetas,
            };
        }
        catch {
            process.stderr.write(`[comdr] probe-v2: _readMetaFile failed for ${absPath}.meta\n`);
            return null;
        }
    }
    safeDir(subPath) {
        const resolved = path.resolve(this._assetsDir, subPath);
        if (!resolved.startsWith(this._assetsDir))
            return '';
        return resolved;
    }
    // walkDir 缓存 — 模块级 Map，跨 ProbeV2 实例复用（TTL 5s，最多 3 槽）。
    // 必须是 static 而非实例属性：index.ts 每个 probe 请求都 new ProbeV2，
    // 实例缓存永远冷启动。模块级缓存让同一轮内多次 retrieve 只扫描一次磁盘。
    // 多槽防止 listAssets(subPath) 覆盖 listAssets() 的 _assetsDir 全量扫描缓存。
    static _walkDirCache = new Map();
    static _WALKDIR_CACHE_MAX = 3;
    walkDir(dir) {
        const now = Date.now();
        const cached = ProbeV2._walkDirCache.get(dir);
        if (cached && (now - cached.time) < 5000) {
            return cached.files;
        }
        const results = [];
        const walk = (d) => {
            try {
                const entries = fs.readdirSync(d, { withFileTypes: true });
                for (const entry of entries) {
                    const fp = path.join(d, entry.name);
                    if (entry.isDirectory() && !entry.name.startsWith('.')) {
                        walk(fp);
                    }
                    else {
                        results.push(fp);
                    }
                }
            }
            catch (e) {
                const code = e.code;
                if (code === 'EACCES' || code === 'EPERM') {
                    process.stderr.write(`[comdr] walkDir permission denied: ${d}\n`);
                }
                else if (code !== 'ENOENT') {
                    process.stderr.write(`[comdr] walkDir error in ${d}: ${(e instanceof Error ? e.message : String(e))}\n`);
                }
            }
        };
        walk(dir);
        // 槽位满时淘汰最旧条目
        if (ProbeV2._walkDirCache.size >= ProbeV2._WALKDIR_CACHE_MAX) {
            let oldestKey = '';
            let oldestTime = Infinity;
            for (const [k, v] of ProbeV2._walkDirCache) {
                if (v.time < oldestTime) {
                    oldestTime = v.time;
                    oldestKey = k;
                }
            }
            ProbeV2._walkDirCache.delete(oldestKey);
        }
        ProbeV2._walkDirCache.set(dir, { files: results, time: now });
        return results;
    }
    fuzzyAssetSearch(query) {
        const lower = query.toLowerCase();
        const allFiles = this.walkDir(this._assetsDir)
            .filter((f) => !f.endsWith(EXT_META) && !f.endsWith(EXT_TS) && !f.endsWith(EXT_JS))
            .map((f) => ({
            absPath: f,
            relPath: path.relative(this._assetsDir, f).replace(/\\/g, '/'),
            name: path.basename(f).toLowerCase(),
        }));
        const matches = allFiles.filter((f) => f.name.includes(lower) || f.relPath.toLowerCase().includes(lower));
        if (matches.length === 0) {
            const fuzzy = [];
            for (const f of allFiles) {
                const d = Math.min((0, levenshtein_1.levenshtein)(lower, f.name, 3), (0, levenshtein_1.levenshtein)(lower, f.relPath.toLowerCase(), 3));
                if (d <= 3)
                    fuzzy.push({ ...f, dist: d });
            }
            fuzzy.sort((a, b) => a.dist - b.dist);
            if (fuzzy.length > 10)
                process.stderr.write(`[comdr] probe-v2 fuzzy search truncated: ${fuzzy.length} → 10 results for "${lower}"\n`);
            return fuzzy.slice(0, 10).map((f) => {
                let uuid = this._readMetaFile(f.absPath)?.uuid || '';
                return { path: f.relPath, uuid };
            });
        }
        matches.sort((a, b) => a.name.length - b.name.length);
        if (matches.length > 10)
            process.stderr.write(`[comdr] probe-v2 exact match truncated: ${matches.length} → 10 results for "${lower}"\n`);
        return matches.slice(0, 10).map((f) => {
            let uuid = '';
            try {
                const meta = JSON.parse(fs.readFileSync(f.absPath + '.meta', 'utf8'));
                uuid = meta.uuid || '';
            }
            catch (e) {
                if (e.code !== 'ENOENT')
                    process.stderr.write(`[comdr] probe-v2 .meta read failed: ${f.absPath}.meta — ${(e instanceof Error ? e.message : String(e))}\n`);
            }
            return { path: f.relPath, uuid };
        });
    }
}
exports.ProbeV2 = ProbeV2;
//# sourceMappingURL=probe-v2.js.map