"use strict";
// ============================================================
// ID 生成工具 — bridge 独立部署，不能 import @comdr/foundation。
//
// 以下函数镜像 foundation/src/foundation/value-kit.ts，修改时必须两边同步：
//   generateFileId()         — Web crypto → Node crypto → LCG → 22c base64url
//   generateFileIdFallback() — LCG PRNG (seed*16807 mod 2^31-1) → 22c base64url
//   generateUuid()           — Web crypto → Node crypto → LCG → UUID v4
//   compressUuid()           — 32 hex → 23c Cocos 压缩格式
//   BASE64_CHARS             — base64 查找表
// ============================================================
// compressUuid: Cocos 3.x 压缩 UUID 格式（32 hex → 5 前缀 + 18 base64）。
//   与 Cocos Creator 编辑器的 UUID 压缩算法一致。
// ============================================================
Object.defineProperty(exports, "__esModule", { value: true });
exports.generateFileId = generateFileId;
exports.generateUuid = generateUuid;
exports.compressUuid = compressUuid;
// 模块级 seed，跨调用持续推进，避免同毫秒内多次调用产生相同 ID
let _fallbackSeed = null;
/** 确定性 PRNG fallback：LCG 产 16 随机字节 → base64url → 22c。
 *  输出格式与 crypto 路径一致，仅随机源降级。
 *  取 LCG 高位字节（>>16 & 0xFF），避免低比特周期性。 */
function generateFileIdFallback() {
    if (_fallbackSeed === null)
        _fallbackSeed = ((Date.now() ^ 0x7F3D) >>> 0) % 2147483647 || 1;
    const bytes = [];
    for (let i = 0; i < 16; i++) {
        _fallbackSeed = (_fallbackSeed * 16807) % 2147483647;
        bytes.push((_fallbackSeed >> 16) & 0xFF);
    }
    let binary = '';
    for (let i = 0; i < bytes.length; i++)
        binary += String.fromCharCode(bytes[i]);
    return btoa(binary).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
}
// Cocos Creator 3.x 使用压缩 UUID 格式（16 随机字节 → base64url → 22 字符）
// bridge 独立部署，不能 import @comdr/core，实现保持一致
let _cryptoBytes = null;
function getCryptoBytes() {
    if (_cryptoBytes)
        return _cryptoBytes;
    // 1. Web crypto (浏览器环境)
    try {
        if (typeof crypto !== 'undefined' && typeof crypto.getRandomValues === 'function') {
            _cryptoBytes = () => {
                const buf = new Uint8Array(16);
                crypto.getRandomValues(buf);
                let binary = '';
                for (let i = 0; i < buf.length; i++)
                    binary += String.fromCharCode(buf[i]);
                return btoa(binary).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
            };
            return _cryptoBytes;
        }
    }
    catch { /* fall through */ }
    // 2. Node crypto (Cocos Editor 环境)
    try {
        const nodeCrypto = require('crypto');
        if (typeof nodeCrypto.randomBytes === 'function') {
            _cryptoBytes = () => nodeCrypto.randomBytes(16).toString('base64')
                .replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
            return _cryptoBytes;
        }
    }
    catch { /* fall through */ }
    // 3. 确定性 LCG fallback
    _cryptoBytes = generateFileIdFallback;
    return _cryptoBytes;
}
function generateFileId() {
    return getCryptoBytes()();
}
// ===== 补充 =====
let _uuidFallbackSeed = null;
/** generateUuid 专用 fallback：LCG PRNG → UUID v4 格式。
 *  独立种子，不与 generateFileId 共享 LCG 状态。 */
function generateUuidFallback() {
    if (_uuidFallbackSeed === null)
        _uuidFallbackSeed = ((Date.now() ^ 0x5A3C) >>> 0) % 2147483647 || 1;
    const hex = 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx';
    const rng = () => {
        _uuidFallbackSeed = (_uuidFallbackSeed * 16807) % 2147483647;
        return _uuidFallbackSeed;
    };
    return hex.replace(/[xy]/g, (c) => {
        const r = (rng() >> 16) & 0xF; // 用高位，避开 LCG 低比特周期性
        const v = c === 'x' ? r : (r & 0x3) | 0x8;
        return v.toString(16);
    });
}
/** 生成标准 UUID v4。按序尝试 Web crypto API → Node crypto 模块 → LCG fallback。 */
function generateUuid() {
    // 1. Web crypto (浏览器环境)
    try {
        if (typeof crypto !== 'undefined' && typeof crypto.randomUUID === 'function') {
            return crypto.randomUUID();
        }
    }
    catch { /* fall through */ }
    // 2. Node crypto 模块 (Cocos Editor 环境)
    try {
        const nodeCrypto = require('crypto');
        if (typeof nodeCrypto.randomUUID === 'function') {
            return nodeCrypto.randomUUID();
        }
    }
    catch { /* fall through */ }
    // 3. 确定性 LCG fallback
    return generateUuidFallback();
}
const BASE64_CHARS = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/';
/** 将标准 UUID 压缩为 Cocos 3.x __type__ 使用的 23 字符格式。
 *  算法：前 5 个 hex 原样保留，剩余 27 个 hex 按 3→2 base64 压缩。 */
function compressUuid(uuid) {
    const hex = uuid.replace(/-/g, '');
    if (hex.length !== 32)
        return uuid;
    let result = hex.substring(0, 5); // 前 5 个 hex 原样
    for (let i = 5; i < 32; i += 3) {
        const val = parseInt(hex.substring(i, i + 3), 16);
        result += BASE64_CHARS[val >> 6] + BASE64_CHARS[val & 0x3F];
    }
    return result; // 5 + 18 = 23 chars
}
//# sourceMappingURL=id-utils.js.map