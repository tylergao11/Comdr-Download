"use strict";
// ============================================================
// ResourceIndex — 项目范围资产索引
// 扫描 .meta、@ccclass、组件使用情况
// 使用 token-based 解析替代正则，正确处理嵌套括号、泛型、多行声明
// ============================================================
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.ResourceIndex = void 0;
const fs = __importStar(require("fs"));
const path = __importStar(require("path"));
const id_utils_1 = require("./id-utils");
const fs_utils_1 = require("./fs-utils");
// ── 镜像 foundation 常量（bridge 独立部署不能 import）──
const EXT_META = '.meta'; // → foundation/constants.ts
const EXT_TS = '.ts'; // → foundation/constants.ts
const EXT_JS = '.js'; // → foundation/constants.ts
const COMDR_TEMP = 'temp/comdr'; // → COMDR_TEMP_DIR
// ===== Token 工具函数 — 替代正则 =====
/** 从 content 中匹配一个 `@identifier` 后的括号内容，返回 match { name, args, endIndex } */
function matchDecorator(content, pos, decorator) {
    const start = content.indexOf(decorator, pos);
    if (start < 0)
        return null;
    let i = start + decorator.length;
    // 跳过空白和注释
    while (i < content.length && (isSpace(content[i]) || content[i] === '\n' || content[i] === '\r'))
        i++;
    if (i < content.length && content[i] === '/' && content[i + 1] === '/') {
        i = skipLineComment(content, i);
        while (i < content.length && (isSpace(content[i]) || content[i] === '\n' || content[i] === '\r'))
            i++;
    }
    // 期望 (
    if (i >= content.length || content[i] !== '(')
        return null;
    const args = balanceParens(content, i);
    if (args === null)
        return null;
    return { args, endIndex: i + args.length + 2 }; // +2 for ()
}
/** 平衡括号: 从 openParen 位置开始，返回括号内内容（不含外层括号），失败返回 null */
function balanceParens(content, openIdx) {
    if (content[openIdx] !== '(')
        return null;
    let depth = 0;
    let inString = null;
    let escape = false;
    for (let i = openIdx; i < content.length; i++) {
        const ch = content[i];
        if (escape) {
            escape = false;
            continue;
        }
        if (inString) {
            if (ch === '\\') {
                escape = true;
                continue;
            }
            if (ch === inString) {
                inString = null;
                continue;
            }
            continue;
        }
        if (ch === '"' || ch === "'" || ch === '`') {
            inString = ch;
            continue;
        }
        if (ch === '(') {
            depth++;
            continue;
        }
        if (ch === ')') {
            depth--;
            if (depth === 0) {
                return content.slice(openIdx + 1, i);
            }
        }
    }
    return null; // 未闭合
}
/** 平衡大括号: 返回 {} 内内容（不含外层），失败返回 null */
function balanceBraces(content, openIdx) {
    if (content[openIdx] !== '{')
        return null;
    let depth = 0;
    let inString = null;
    let escape = false;
    for (let i = openIdx; i < content.length; i++) {
        const ch = content[i];
        if (escape) {
            escape = false;
            continue;
        }
        if (inString) {
            if (ch === '\\') {
                escape = true;
                continue;
            }
            if (ch === inString) {
                inString = null;
                continue;
            }
            continue;
        }
        if (ch === '"' || ch === "'" || ch === '`') {
            inString = ch;
            continue;
        }
        if (ch === '{') {
            depth++;
            continue;
        }
        if (ch === '}') {
            depth--;
            if (depth === 0) {
                return content.slice(openIdx + 1, i);
            }
        }
    }
    return null;
}
/** 从括号内容中提取第一个字符串字面量（单引号或双引号） */
function extractString(bracketedContent) {
    const trimmed = bracketedContent.trim();
    // 直接是字符串字面量
    if ((trimmed.startsWith("'") || trimmed.startsWith('"')) && trimmed.length >= 2) {
        const q = trimmed[0];
        const close = trimmed.indexOf(q, 1);
        if (close > 0)
            return trimmed.slice(1, close);
    }
    // 对象字面量 { name: 'Foo' } 或 { name: "Foo" }
    const nameMatch = /\bname\s*:\s*['"](\w+)['"]/.exec(trimmed);
    if (nameMatch)
        return nameMatch[1];
    return null;
}
/** 跳过 // 注释行 */
function skipLineComment(content, pos) {
    while (pos < content.length && content[pos] !== '\n' && content[pos] !== '\r')
        pos++;
    return pos;
}
/** 跳过块注释 */
function skipBlockComment(content, pos) {
    const end = content.indexOf('*/', pos);
    if (end < 0)
        return pos;
    return end + 2;
}
function isSpace(ch) {
    return ch === ' ' || ch === '\t';
}
/** 跳过空白和注释，返回第一个非空非注释字符的位置 */
function skipWhitespaceAndComments(content, pos) {
    while (pos < content.length) {
        const ch = content[pos];
        if (isSpace(ch) || ch === '\n' || ch === '\r') {
            pos++;
            continue;
        }
        if (ch === '/' && pos + 1 < content.length) {
            if (content[pos + 1] === '/') {
                pos = skipLineComment(content, pos);
                continue;
            }
            if (content[pos + 1] === '*') {
                pos = skipBlockComment(content, pos);
                continue;
            }
        }
        break;
    }
    return pos;
}
/** 读取一个标识符（字母/数字/下划线），返回标识符和结束位置 */
function readIdentifier(content, pos) {
    let i = pos;
    while (i < content.length && /[\w$]/.test(content[i]))
        i++;
    if (i === pos)
        return null;
    return { name: content.slice(pos, i), end: i };
}
/** 读取类型注解（`: type`）后的类型部分，返回结束位置。只跳过，不解析 */
function skipTypeAnnotation(content, pos) {
    let i = pos;
    i = skipWhitespaceAndComments(content, i);
    if (i < content.length && content[i] === ':') {
        i++;
        i = skipWhitespaceAndComments(content, i);
        // 跳过类型表达式：处理嵌套泛型 <>
        i = skipTypeExpression(content, i);
    }
    return i;
}
function skipTypeExpression(content, pos) {
    let i = pos;
    let depth = 0;
    let inString = null;
    let escape = false;
    while (i < content.length) {
        const ch = content[i];
        if (escape) {
            escape = false;
            i++;
            continue;
        }
        if (inString) {
            if (ch === '\\') {
                escape = true;
                i++;
                continue;
            }
            if (ch === inString) {
                inString = null;
                i++;
                continue;
            }
            i++;
            continue;
        }
        if (ch === '"' || ch === "'" || ch === '`') {
            inString = ch;
            i++;
            continue;
        }
        if (ch === '<' || ch === '(') {
            depth++;
            i++;
            continue;
        }
        if (ch === '>' || ch === ')') {
            depth--;
            if (depth < 0)
                return i;
            i++;
            continue;
        }
        // 类型表达式结束字符
        if (depth === 0 && (ch === ';' || ch === '=' || ch === ',' || ch === '\n' || ch === '{' || ch === '}')) {
            return i;
        }
        i++;
    }
    return i;
}
// ===== 提取函数 — 替代旧正则 =====
/** 提取 @ccclass 类名 */
function extractCcClassName(content) {
    const decorator = matchDecorator(content, 0, '@ccclass');
    if (!decorator)
        return null;
    return extractString(decorator.args);
}
/** 提取方法名列表 */
function extractMethodNames(content) {
    const names = [];
    let pos = 0;
    while (pos < content.length) {
        // 跳过空白/注释
        pos = skipWhitespaceAndComments(content, pos);
        if (pos >= content.length)
            break;
        // 跳过 decorator（如 @property）
        if (content[pos] === '@') {
            while (pos < content.length && content[pos] !== '\n' && content[pos] !== '\r')
                pos++;
            continue;
        }
        // 跳过 access modifiers + async/static
        const start = pos;
        pos = skipWhitespaceAndComments(content, pos);
        // 读取可能的修饰符序列
        let foundKeyword = true;
        while (foundKeyword) {
            const word = peekWord(content, pos);
            if (word === 'public' || word === 'private' || word === 'protected' ||
                word === 'static' || word === 'async' || word === 'get' || word === 'set') {
                pos += word.length;
                pos = skipWhitespaceAndComments(content, pos);
            }
            else {
                foundKeyword = false;
            }
        }
        // 读取方法名
        const idResult = readIdentifier(content, pos);
        if (!idResult) {
            pos++;
            continue;
        }
        // 检查后面是否是 ( — 这才是方法
        let afterId = skipWhitespaceAndComments(content, idResult.end);
        if (afterId < content.length && content[afterId] === '(') {
            // 平衡括号跳过参数列表
            const argsContent = balanceParens(content, afterId);
            if (argsContent !== null) {
                const parenEnd = afterId + argsContent.length + 2;
                let afterParen = skipWhitespaceAndComments(content, parenEnd);
                // 跳过返回类型注解
                afterParen = skipTypeAnnotation(content, afterParen);
                // 期望 { 或 ;
                afterParen = skipWhitespaceAndComments(content, afterParen);
                if (afterParen < content.length && (content[afterParen] === '{' || content[afterParen] === ';')) {
                    if (!names.includes(idResult.name)) {
                        names.push(idResult.name);
                    }
                }
            }
        }
        pos = afterId;
    }
    return names;
}
function peekWord(content, pos) {
    let i = pos;
    while (i < content.length && /[a-zA-Z_]/.test(content[i]))
        i++;
    return content.slice(pos, i);
}
/** Cocos TypeScript 类型名 → schema type 字符串映射 */
const TYPE_MAP = {
    // 节点
    'Node': 'node', 'cc.Node': 'node',
    // 资产类型 — 外部导入的图片/音效/动画/字体等
    'SpriteFrame': 'asset', 'cc.SpriteFrame': 'asset',
    'SpriteAtlas': 'asset', 'cc.SpriteAtlas': 'asset',
    'Prefab': 'asset', 'cc.Prefab': 'asset',
    'Asset': 'asset', 'cc.Asset': 'asset',
    'Texture2D': 'asset', 'cc.Texture2D': 'asset',
    'TextureCube': 'asset', 'cc.TextureCube': 'asset',
    'ImageAsset': 'asset', 'cc.ImageAsset': 'asset',
    'AnimationClip': 'asset', 'cc.AnimationClip': 'asset',
    'AudioClip': 'asset', 'cc.AudioClip': 'asset',
    'Material': 'asset', 'cc.Material': 'asset',
    'EffectAsset': 'asset', 'cc.EffectAsset': 'asset',
    'RenderTexture': 'asset', 'cc.RenderTexture': 'asset',
    'Font': 'asset', 'cc.Font': 'asset', 'TTFFont': 'asset', 'cc.TTFFont': 'asset',
    'JsonAsset': 'asset', 'cc.JsonAsset': 'asset',
    'TextAsset': 'asset', 'cc.TextAsset': 'asset',
    // 骨骼动画资产
    'SkeletonData': 'asset', 'sp.SkeletonData': 'asset',
    'DragonBonesAsset': 'asset', 'dragonBones.DragonBonesAsset': 'asset',
    'DragonBonesAtlasAsset': 'asset', 'dragonBones.DragonBonesAtlasAsset': 'asset',
    // 基础类型
    'string': 'string', 'String': 'string',
    'number': 'float', 'float': 'float', 'int': 'float', 'integer': 'float',
    'boolean': 'bool', 'bool': 'bool',
    // 数学类型
    'Vec2': 'vec2', 'cc.Vec2': 'vec2',
    'Vec3': 'vec3', 'cc.Vec3': 'vec3',
    'Vec4': 'vec4', 'cc.Vec4': 'vec4',
    'Color': 'color', 'cc.Color': 'color',
    'Size': 'size', 'cc.Size': 'size',
    'Rect': 'rect', 'cc.Rect': 'rect',
    'Quat': 'quat', 'cc.Quat': 'quat',
};
function mapTypeName(tsType) {
    // 数组类型：[cc.Node] 或 cc.Node[] 或 Node[]
    const arrayMatch = tsType.match(/^\[(.+)\]$/);
    if (arrayMatch)
        return 'array';
    if (tsType.endsWith('[]'))
        return 'array';
    // 直接查表
    const mapped = TYPE_MAP[tsType];
    if (mapped)
        return mapped;
    // 包含 cc. 或 sp. 前缀的资产类型 → 'asset'
    if (tsType.startsWith('cc.') || tsType.startsWith('sp.') || tsType.startsWith('dragonBones.'))
        return 'asset';
    return undefined;
}
/** 从 @property 装饰器参数中提取 type 值 */
function parsePropertyType(args) {
    const trimmed = args.trim();
    if (!trimmed)
        return undefined;
    // 简写: @property(Node) 或 @property(cc.Node)
    if (!trimmed.startsWith('{')) {
        return mapTypeName(trimmed);
    }
    // 对象字面量: @property({ type: Node })
    const content = trimmed.slice(1, -1); // 去掉 {}
    const typeMatch = /\btype\s*:\s*(\S+)/.exec(content);
    if (typeMatch) {
        let typeVal = typeMatch[1];
        // 去除尾部逗号/空白
        typeVal = typeVal.replace(/[,;]\s*$/, '').trim();
        return mapTypeName(typeVal);
    }
    return undefined;
}
/** 提取 @property 属性列表，含类型推断 */
function extractPropertyNames(content) {
    const result = [];
    const seen = new Set();
    let pos = 0;
    while (pos < content.length) {
        const nextAt = content.indexOf('@property', pos);
        if (nextAt < 0)
            break;
        let after = nextAt + '@property'.length;
        after = skipWhitespaceAndComments(content, after);
        let propType;
        if (after < content.length && content[after] === '(') {
            const args = balanceParens(content, after);
            if (args !== null) {
                propType = parsePropertyType(args);
                after = after + args.length + 2;
                after = skipWhitespaceAndComments(content, after);
            }
        }
        const idResult = readIdentifier(content, after);
        if (idResult) {
            let name = idResult.name;
            let end = idResult.end;
            // 跳过修饰符关键字，读真正的属性名
            if (['public', 'private', 'protected', 'static', 'readonly', 'get', 'set', 'async'].includes(name)) {
                const nextWs = skipWhitespaceAndComments(content, end);
                const nextId = readIdentifier(content, nextWs);
                if (nextId) {
                    name = nextId.name;
                    end = nextId.end;
                }
            }
            if (!seen.has(name)) {
                seen.add(name);
                result.push({ name, type: propType });
            }
            pos = end;
        }
        else {
            pos = nextAt + 1;
        }
    }
    return result;
}
// ===== ResourceIndex 类 =====
class ResourceIndex {
    _projectPath;
    _scripts = [];
    _assetPaths = new Map(); // path → uuid
    constructor(projectPath) {
        this._projectPath = projectPath;
    }
    async fullScan() {
        this._scripts = [];
        this._assetPaths.clear();
        const assetsDir = path.join(this._projectPath, 'assets');
        this._scanDir(assetsDir);
        // 保存到 temp/comdr/resource-index.json
        const outputDir = path.join(this._projectPath, COMDR_TEMP);
        fs.mkdirSync(outputDir, { recursive: true });
        const outputPath = path.join(outputDir, 'resource-index.json');
        const data = {
            schema: 'Comdr.resource-index.v2',
            updatedAt: new Date().toISOString(),
            scripts: this._scripts.map((s) => ({
                name: s.name,
                path: s.path,
                compressedId: s.compressedId,
                methods: s.methods,
                properties: s.properties.map((p) => (p.type ? { name: p.name, type: p.type } : p.name)),
            })),
            assetCount: this._assetPaths.size,
        };
        (0, fs_utils_1.writeJsonAtomic)(outputPath, data);
    }
    getScripts() {
        return this._scripts;
    }
    getSummary() {
        const totalScripts = this._scripts.length;
        return {
            scriptCount: totalScripts,
            assetCount: this._assetPaths.size,
            truncated: totalScripts > 50,
            scripts: this._scripts.slice(0, 50).map((s) => ({
                name: s.name,
                path: s.path,
                methodCount: s.methods.length,
            })),
        };
    }
    _scanDir(dir) {
        try {
            const entries = fs.readdirSync(dir, { withFileTypes: true });
            for (const entry of entries) {
                if (entry.name.startsWith('.') || entry.name === 'node_modules')
                    continue;
                const fullPath = path.join(dir, entry.name);
                if (entry.isDirectory()) {
                    this._scanDir(fullPath);
                }
                else {
                    this._processFile(fullPath);
                }
            }
        }
        catch (e) {
            console.warn('[comdr] resource-index scan error:', (e instanceof Error ? e.message : String(e)));
        }
    }
    _processFile(filePath) {
        // .meta 文件：提取 UUID
        if (filePath.endsWith(EXT_META)) {
            try {
                const raw = fs.readFileSync(filePath, 'utf8');
                const meta = JSON.parse(raw);
                if (meta.uuid) {
                    const assetPath = filePath.slice(0, -5); // 去掉 .meta
                    this._assetPaths.set(assetPath, meta.uuid);
                }
            }
            catch (e) {
                console.warn('[comdr] resource-index scan error:', (e instanceof Error ? e.message : String(e)));
            }
        }
        // .ts/.js 文件：提取 @ccclass
        if (filePath.endsWith(EXT_TS) || filePath.endsWith(EXT_JS)) {
            try {
                const content = fs.readFileSync(filePath, 'utf8');
                // token-based @ccclass 提取
                const className = extractCcClassName(content);
                if (!className)
                    return;
                // 读取对应 .meta 文件的 UUID 并压缩；不存在则自动生成
                let compressedId = '';
                let uuid = '';
                const metaPath = filePath + EXT_META;
                try {
                    if (fs.existsSync(metaPath)) {
                        const meta = JSON.parse(fs.readFileSync(metaPath, 'utf8'));
                        uuid = meta.uuid || '';
                    }
                }
                catch (e) {
                    console.warn(`[comdr] resource-index meta read failed: ${filePath} — ${e instanceof Error ? e.message : String(e)}`);
                }
                // 无 .meta → 内存生成临时 UUID 供索引（不写盘，避免与 Cocos 的 UUID 管理冲突）
                // Cocos 编译脚本后会创建真实 .meta，下轮扫描自动切换到 Cocos 分配的 UUID。
                if (!uuid) {
                    uuid = (0, id_utils_1.generateUuid)();
                    process.stderr.write(`[comdr] resource-index: temp UUID for ${filePath} — Cocos .meta not yet created\n`);
                }
                if (uuid) {
                    compressedId = (0, id_utils_1.compressUuid)(uuid);
                }
                // token-based 提取
                const methods = extractMethodNames(content);
                const properties = extractPropertyNames(content);
                this._scripts.push({
                    name: className,
                    path: filePath,
                    compressedId,
                    methods,
                    properties,
                });
            }
            catch (e) {
                console.warn('[comdr] resource-index scan error:', (e instanceof Error ? e.message : String(e)));
            }
        }
    }
}
exports.ResourceIndex = ResourceIndex;
//# sourceMappingURL=resource-index.js.map