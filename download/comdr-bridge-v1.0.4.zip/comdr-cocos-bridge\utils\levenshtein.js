"use strict";
// ============================================================
// Bridge 内部共享 — Levenshtein 编辑距离
// document.ts 和 probe-v2.ts 共用。单行 DP + 长度预过滤。
// O(min(m,n)) 空间，O(m×n) 时间。
// ============================================================
Object.defineProperty(exports, "__esModule", { value: true });
exports.levenshtein = levenshtein;
function levenshtein(a, b, maxDist = Infinity) {
    if (Math.abs(a.length - b.length) > maxDist)
        return maxDist + 1;
    if (a.length > b.length) {
        const t = a;
        a = b;
        b = t;
    }
    const m = a.length, n = b.length;
    let prev = new Array(m + 1);
    let curr = new Array(m + 1);
    for (let i = 0; i <= m; i++)
        prev[i] = i;
    for (let j = 1; j <= n; j++) {
        curr[0] = j;
        let rowMin = j;
        for (let i = 1; i <= m; i++) {
            curr[i] = a[i - 1] === b[j - 1] ? prev[i - 1] : 1 + Math.min(prev[i], curr[i - 1], prev[i - 1]);
            if (curr[i] < rowMin)
                rowMin = curr[i];
        }
        if (rowMin > maxDist)
            return maxDist + 1;
        [prev, curr] = [curr, prev];
    }
    return prev[m];
}
//# sourceMappingURL=levenshtein.js.map