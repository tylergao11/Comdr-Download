"use strict";
// ============================================================
// @comdr/bridge — Cocos Creator 扩展入口
// 替代原 main.js，在 Cocos Editor 进程中运行
// ============================================================
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.VERSION = void 0;
exports.load = load;
exports.unload = unload;
exports.open = open;
exports.getProjectInfo = getProjectInfo;
exports.runTaskCard = runTaskCardFromEditor;
const fs = __importStar(require("fs"));
const os = __importStar(require("os"));
const path = __importStar(require("path"));
const document_1 = require("./document");
const probe_v2_1 = require("./probe-v2");
const asset_writer_1 = require("./asset-writer");
const path_utils_1 = require("./path-utils");
const resource_index_1 = require("./resource-index");
const task_bridge_1 = require("./task-bridge");
const fs_utils_1 = require("./fs-utils");
const error_codes_1 = require("./error-codes");
// ── 镜像 foundation 常量（bridge 独立部署不能 import）──
const COMDR_TEMP = 'temp/comdr'; // → COMDR_TEMP_DIR
const ENV_COMDR_DIAG = 'COMDR_DIAG'; // → ENV_COMDR_DIAG
/** 镜像 foundation/getComdrHome */
function getComdrHome() {
    const home = process.env.HOME || process.env.USERPROFILE;
    if (home)
        return require('path').join(home, '.comdr');
    return require('path').join(os.tmpdir(), '.comdr');
}
var version_1 = require("./version");
Object.defineProperty(exports, "VERSION", { enumerable: true, get: function () { return version_1.VERSION; } });
// ===== 扩展生命周期 =====
let taskBridge = null;
let resourceIndex = null;
async function load() {
    // COMDR_DIAG: 诊断文件写入（bridge-startup.log / bridge-crash.log / save-diag.json）
    // 均受此环境变量控制，生产默认关闭。
    // 开启: COMDR_DIAG=1 npm run build && npm run sync-bridge
    if (process.env[ENV_COMDR_DIAG]) {
        try {
            const startupMarker = path.join(Editor.Project.path, COMDR_TEMP);
            fs.mkdirSync(startupMarker, { recursive: true });
            fs.writeFileSync(path.join(startupMarker, 'bridge-startup.log'), `load() called at ${new Date().toISOString()}\n`, 'utf8');
        }
        catch (e) {
            process.stderr.write(`[comdr] Bridge startup marker failed: ${(e instanceof Error ? e.message : String(e))}\n`);
        }
    }
    console.log('[Comdr Bridge] Loading...');
    try {
        // 1. 从扩展目录读取 component-cache.json（sync-bridge 构建时生成，零运行时依赖）
        ensureComponentCache();
        // 2. 初始化资源索引 + 全量扫描（await 完成后再标记就绪）
        resourceIndex = new resource_index_1.ResourceIndex(Editor.Project.path);
        resourceIndex.fullScan().then(() => {
            taskBridge?.setSystemsReady();
        }).catch((e) => {
            console.warn(`[Comdr Bridge] ResourceIndex scan failed — bridge started with degraded asset/script data: ${e instanceof Error ? e.message : String(e)}`);
            taskBridge?.setSystemsReady(); // 核心编辑功能正常，资源搜索降级
        });
        // 3. 初始化任务桥接
        taskBridge = new task_bridge_1.TaskBridge({
            getProjectPath: () => Editor.Project.path,
            getEditorAppPath: () => Editor.App.path,
            getOpenDocument: () => {
                const doc = getDoc();
                return doc ? { kind: doc.kind, path: doc.dbUrl || '', name: doc.rootName || '', rootNodeUuid: doc.ctx().rootNodeUuid || '' } : null;
            },
            runTaskCard: runTaskCardFromEditor,
        });
        taskBridge.start();
        // 向 ~/.comdr 注册——Server 据此发现项目并主动构建星图
        try {
            const regDir = getComdrHome();
            const regPath = path.join(regDir, 'bridge-registry.json');
            if (!fs.existsSync(regDir))
                fs.mkdirSync(regDir, { recursive: true });
            let registry = {};
            if (fs.existsSync(regPath)) {
                try {
                    registry = JSON.parse(fs.readFileSync(regPath, 'utf8'));
                }
                catch { /* reset */ }
            }
            registry[Editor.Project.path] = {
                projectPath: Editor.Project.path,
                seenAt: new Date().toISOString(),
            };
            const tmp = regPath + '.tmp';
            fs.writeFileSync(tmp, JSON.stringify(registry), 'utf8');
            fs.renameSync(tmp, regPath);
        }
        catch (e) {
            process.stderr.write(`[comdr] Bridge registry write failed: ${e instanceof Error ? e.message : String(e)}\n`);
        }
        console.log('[Comdr Bridge] Loaded — waiting for ResourceIndex scan...');
    }
    catch (err) {
        console.error('[Comdr Bridge] Load failed:', err);
        // 写崩溃日志到项目 temp 目录（仅 COMDR_DIAG 环境变量时启用）
        if (process.env[ENV_COMDR_DIAG]) {
            try {
                const crashDir = path.join(Editor.Project.path, COMDR_TEMP);
                fs.mkdirSync(crashDir, { recursive: true });
                const crashMsg = `${new Date().toISOString()}\n${err instanceof Error ? err.message : String(err)}\n${err instanceof Error ? (err.stack || '') : ''}\n`;
                fs.writeFileSync(path.join(crashDir, 'bridge-crash.log'), crashMsg, 'utf8');
            }
            catch (e2) {
                process.stderr.write(`[comdr] Bridge crash log write also failed: ${e2 instanceof Error ? e2.message : String(e2)}\n`);
            }
        }
    }
}
/**
 * 将 bridge dist 内置的 component-cache.json 复制到项目 temp 目录。
 * 不需要 typescript、不需要 AST parser 运行时加载。
 * component-cache.json 由 sync-bridge.ts 在构建时生成。
 */
function ensureComponentCache() {
    const projectPath = Editor.Project.path;
    const destPath = path.join(projectPath, COMDR_TEMP, 'component-cache.json');
    // 如果项目 temp 下已有，跳过（避免重复写入）
    if (fs.existsSync(destPath)) {
        console.log('[Comdr Bridge] component-cache.json already exists in project temp');
        return;
    }
    // 从扩展根目录读取内置的 component-cache.json
    const bundledPath = path.join(__dirname, 'component-cache.json');
    if (fs.existsSync(bundledPath)) {
        try {
            const destDir = path.dirname(destPath);
            if (!fs.existsSync(destDir)) {
                fs.mkdirSync(destDir, { recursive: true });
            }
            fs.copyFileSync(bundledPath, destPath);
            console.log('[Comdr Bridge] component-cache.json deployed from bundle');
        }
        catch (e) {
            console.warn('[Comdr Bridge] Failed to copy component-cache.json:', (e instanceof Error ? e.message : String(e)));
        }
    }
    else {
        console.warn('[Comdr Bridge] component-cache.json not bundled — run sync-bridge to generate it');
    }
}
function unload() {
    if (taskBridge) {
        taskBridge.stop();
        taskBridge = null;
    }
    console.log('[Comdr Bridge] Unloaded');
}
// ===== 消息处理 =====
function open(assetPath) {
    return Editor.Message.request('asset-db', 'open-asset', assetPath);
}
function getProjectInfo() {
    return {
        path: Editor.Project.path,
        name: path.basename(Editor.Project.path),
        engineVersion: Editor.App.version,
    };
}
// ===== 文档注册表（支持多窗口：path → Document） =====
const _openDocs = new Map();
let _activeDocPath = null;
function getDoc() {
    if (!_activeDocPath)
        return null;
    return _openDocs.get(_activeDocPath) || null;
}
function setDoc(path, doc) {
    _openDocs.set(path, doc);
    _activeDocPath = path;
}
function clearDoc(path) {
    if (path) {
        _openDocs.delete(path);
        if (_activeDocPath === path)
            _activeDocPath = null;
    }
    else {
        _openDocs.clear();
        _activeDocPath = null;
    }
}
// ===== 任务分发 =====
// 防重入由 task-bridge._processing 保证，不在此处重复
// ===== 任务处理器 =====
async function _handleProbe(projectPath, payload) {
    const doc = getDoc();
    const probe = new probe_v2_1.ProbeV2(projectPath, doc, _openDocs);
    if (resourceIndex)
        probe.setResourceIndex(resourceIndex);
    const kind = (payload.probeType || payload.kind || 'assets');
    return probe.handle({
        kind: kind,
        path: payload.path,
        name: payload.name,
        pattern: payload.pattern,
        fileId: (payload.nodeUuid || payload.id || payload.fileId),
        componentType: (payload.componentType || payload.component),
        property: payload.property,
        level: payload.level,
        limit: payload.limit,
        query: payload.query,
    });
}
async function _handleWrite(projectPath, payload) {
    const writer = new asset_writer_1.AssetWriter(projectPath);
    const writeResult = await writer.writeAsset(payload);
    const wrotePath = writeResult.path;
    if (wrotePath && _activeDocPath) {
        const normalizedActive = (0, path_utils_1.normalizeAssetPath)(_activeDocPath).fsPath;
        if (wrotePath === normalizedActive) {
            const reopen = document_1.Document.open(projectPath, wrotePath);
            if (reopen.ok)
                setDoc(wrotePath, reopen.doc);
        }
    }
    return writeResult;
}
function _handleOpen(projectPath, payload) {
    const openPath = payload.path;
    const result = document_1.Document.open(projectPath, openPath);
    if (result.ok) {
        setDoc(openPath, result.doc);
        const ctx = result.doc.ctx();
        return { ok: true, kind: result.doc.kind, dbUrl: result.doc.dbUrl, name: result.doc.rootName, rootNodeUuid: ctx.rootNodeUuid };
    }
    clearDoc(openPath);
    return result;
}
function _handleEdit(payload) {
    const doc = getDoc();
    if (!doc)
        return { ok: false, error: error_codes_1.MSG_NO_DOCUMENT_OPEN, code: error_codes_1.ERR_BR_NO_DOC };
    return doc.edit(payload.editType, payload);
}
async function _handleSave(projectPath) {
    const doc = getDoc();
    if (!doc)
        return { ok: false, error: error_codes_1.MSG_NO_DOCUMENT_OPEN, code: error_codes_1.ERR_BR_NO_DOC };
    if (!doc.isDirty)
        return { ok: true, path: '' };
    const normalized = (0, path_utils_1.normalizeAssetPath)(doc.dbUrl);
    const savePath = path.join(projectPath, normalized.fsPath);
    if (!fs.existsSync(path.dirname(savePath))) {
        return { ok: false, error: `Save directory does not exist: ${path.dirname(savePath)}`, code: error_codes_1.ERR_BR_NO_DOC };
    }
    (0, fs_utils_1.writeFileAtomic)(savePath, doc.serialize());
    doc.setPath(normalized.fsPath, doc.kind);
    try {
        await Editor.Message.request('asset-db', 'refresh-asset', savePath);
    }
    catch (e) {
        process.stderr.write(`[comdr] Editor refresh-asset failed for ${savePath}: ${e instanceof Error ? e.message : String(e)}\n`);
    }
    return { ok: true, path: normalized.fsPath };
}
async function _handleRemapRefs(projectPath, payload) {
    const target = payload.target;
    const from = payload.from;
    const to = payload.to;
    if (!target || !from || !to)
        return { ok: false, error: 'Missing target, from or to path' };
    const remapResult = await (0, asset_writer_1.remapRefs)(projectPath, target, from, to);
    if (remapResult.ok && _activeDocPath) {
        const normTarget = (0, path_utils_1.normalizeAssetPath)(target).fsPath;
        const normActive = (0, path_utils_1.normalizeAssetPath)(_activeDocPath).fsPath;
        const matchesFile = normActive === normTarget;
        const matchesDir = normActive.startsWith(normTarget + '/') || normActive.startsWith(normTarget.replace(/\/?$/, '/'));
        if (matchesFile || matchesDir) {
            const reopen = document_1.Document.open(projectPath, normActive);
            if (reopen.ok)
                setDoc(normActive, reopen.doc);
        }
    }
    return remapResult;
}
// ===== 任务分发 =====
async function runTaskCardFromEditor(taskCard) {
    try {
        const { type, payload = {} } = taskCard;
        const projectPath = Editor.Project.path;
        switch (type) {
            case 'probe': return _handleProbe(projectPath, payload);
            case 'write': return _handleWrite(projectPath, payload);
            case 'open': return _handleOpen(projectPath, payload);
            case 'edit': return _handleEdit(payload);
            case 'save': return _handleSave(projectPath);
            case 'copy-file': return (0, asset_writer_1.copyFileOrFolder)(projectPath, payload.source, payload.dest);
            case 'remap-refs': return _handleRemapRefs(projectPath, payload);
            default: throw new Error(`Unknown task type: ${type}`);
        }
    }
    finally {
        // cleanup handled by task-bridge._processing
    }
}
//# sourceMappingURL=index.js.map