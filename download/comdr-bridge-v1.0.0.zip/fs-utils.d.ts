/** 原子写入 JSON 文件：先写 tmp 再 rename，防止崩溃损坏用户资产 */
export declare function writeJsonAtomic(filePath: string, data: unknown): void;
//# sourceMappingURL=fs-utils.d.ts.map