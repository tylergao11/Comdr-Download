/** 文档编辑操作类型 */
export declare const EditType: {
    readonly ADD_COMPONENT: "add-component";
    readonly SET_PROP: "set-prop";
    readonly SET_PROPS: "set-props";
    readonly DELETE_NODE: "delete-node";
    readonly REPARENT: "reparent";
    readonly DUPLICATE: "duplicate";
    readonly SET_ACTIVE: "set-active";
    readonly ADD_NODE_TREE: "add-node-tree";
    readonly RENAME_NODE: "rename-node";
};
export type EditType = (typeof EditType)[keyof typeof EditType];
/** 文档类型。单一真相源：@comdr/foundation model/cocos-world.ts DocumentKind。
 *  Bridge 独立部署不能 import foundation，修改时两边必须同步。 */
export type DocumentKind = 'scene' | 'prefab' | 'none';
interface CocosObject {
    __type__?: string;
    __id__?: number;
    __uuid__?: string;
    __deleted__?: boolean;
    _name?: string;
    _objFlags?: number;
    _children?: Array<{
        __id__: number;
    }>;
    _components?: Array<{
        __id__: number;
    }>;
    _prefab?: {
        __id__: number;
    };
    _parent?: {
        __id__: number;
    } | null;
    _active?: boolean;
    _enabled?: boolean;
    _id?: string;
    node?: {
        __id__: number;
    };
    fileId?: string;
    data?: {
        __id__: number;
    };
    root?: {
        __id__: number;
    };
    asset?: null | {
        __uuid__: string;
    };
    sync?: boolean;
    [key: string]: unknown;
}
interface TreeNode {
    nodeUuid: string;
    name: string;
    path: string;
    active: boolean;
    childCount: number;
    children: TreeNode[];
    components: ComponentInfo[];
}
interface ComponentInfo {
    componentUuid: string;
    type: string;
    enabled: boolean;
    properties: Record<string, unknown>;
}
interface FindNodeResult {
    nodeObj: CocosObject;
    nodeIndex: number;
    prefabInfo: CocosObject;
    prefabInfoIndex: number;
}
interface FindComponentResult {
    compObj: CocosObject;
    compIndex: number;
    compPrefabInfo: CocosObject;
    compPrefabInfoIndex: number;
    fileId: string;
}
export declare function setComponentTemplateProvider(fn: (typeName: string) => Record<string, unknown> | null): void;
export declare class Document {
    private _json;
    private _tree;
    private _path;
    private _kind;
    private _dirty;
    private _snapshot;
    /** 加载时文件修改时间，用于检测外部编辑器变更 */
    private _lastMtime;
    private _nodeFlatIndex;
    private _nodeIdIndex;
    private _prefabInfoIndex;
    private _compToCpiIndex;
    constructor(jsonArray: CocosObject[], assetPath: string, kind: DocumentKind, tree: TreeNode | null);
    get kind(): DocumentKind;
    get dbUrl(): string;
    get isDirty(): boolean;
    get rootName(): string;
    static open(projectPath: string, assetPath: string, kind?: DocumentKind): {
        ok: true;
        doc: Document;
    } | {
        ok: false;
        error: string;
        code: string;
    };
    static create(rootName: string, kind?: DocumentKind): {
        ok: true;
        doc: Document;
    };
    serialize(): string;
    setPath(assetPath: string, kind?: DocumentKind): void;
    ctx(): {
        rootTree: TreeNode | null;
        name: string;
        rootNodeUuid: string;
        childCount: number;
        capturedNodeCount: number;
    };
    detail(fileId: string): Record<string, unknown> | null;
    readProperty(rawRef: string, componentType: string, propertyName?: string): Record<string, unknown>;
    /** 惰性构建 PrefabInfo 索引（fileId → _json 数组下标），O(1) findNode */
    private _ensurePrefabInfoIndex;
    /** _json 变异后使惰性索引失效（_prefabInfoIndex / _compToCpiIndex 有 ensure 方法惰性重建）。
     *  _nodeIdIndex 由 rebuildFlatIndex 维护——每次 edit 成功后重建，不应在此清空。 */
    private _invalidateCaches;
    findNode(fileId: string): FindNodeResult | null;
    /** 惰性构建 CompPrefabInfo → Component 反向索引 */
    private _ensureCompToCpiIndex;
    findComponent(fileId: string): FindComponentResult | null;
    findComponentByType(nodeFileId: string, componentType: string): FindComponentResult | null;
    /** 统一节点引用解析入口。
     *  接受 #fileId / 路径 / 模糊名，返回 FindNodeResult 或错误。
     *  edit() 和 readProperty() 在处理前调用此方法。 */
    resolveNodeRef(ref: string): FindNodeResult | {
        ok: false;
        error: string;
        code: string;
        matches?: Array<{
            name: string;
            path: string;
            fileId: string;
        }>;
    };
    /** 模糊名搜索（供 retrieve(find-in-doc) 使用） */
    findNodesByFuzzyName(query: string, maxResults?: number): Array<{
        name: string;
        path: string;
        fileId: string;
        childCount: number;
        compTypes: string[];
    }>;
    /** 模糊名匹配引擎 */
    private _fuzzyMatchNames;
    /** 从 _buildTree 产物重建索引（flat 名索引 + 节点级 fileId 索引）
     *  @param prebuilt _buildTree 返回的预收集 flat 数据
     *  @param nodeIdIndex _buildTree 返回的 fileId → 节点数组索引 */
    rebuildFlatIndex(prebuilt?: Array<{
        name: string;
        fileId: string;
        path: string;
        compTypes: string[];
        childCount: number;
    }>, nodeIdIndex?: Map<string, number>): void;
    edit(editType: string, payload: Record<string, unknown>): Record<string, unknown>;
    save(): {
        ok: boolean;
        path?: string;
        error?: string;
    };
    private get _dbUrl();
    private _rollback;
    private _addComponent;
    /** 将 Gateway 组装的子树追加到已有文档末尾。
     *  subtree 带 local __id__，本方法做 offset+remap，
     *  与 _duplicateNode 共享 _remapObjRefs 核心逻辑。 */
    private _addNodeTree;
    /** 将 prop 值中的 #fileId 解析为 {__id__:N} 供 Cocos JSON 内部引用 */
    private _resolvePropValue;
    private _setProperty;
    private _setProperties;
    private _deleteNode;
    private _reparentNode;
    private _duplicateNode;
    private _setNodeActive;
    /** 重命名节点：修改节点对象的 _name 字段 */
    private _renameNode;
    /** 将所有存活对象中对已删除索引的 { __id__: N } 引用替换为 null */
    private _nullifyDeletedRefs;
    private _findNodeInTree;
    private static _buildTree;
    private static _countNodes;
    private static _buildPaths;
    private static _safeProp;
    private static _compact;
    private static _remapIds;
    private static _collectSubtree;
    private static _applyProp;
    private static _applyWidgetProp;
    /** 读取属性当前值（与 _applyProp 的查找逻辑对称） */
    private static _readProp;
    /** 从当前节点沿 _parent 链向上查找最近的 cc.PrefabInstance 对象。
     *  返回 PrefabInstance 对象（json 数组中的原始对象），或 null（不在嵌套预制体内）。 */
    private _findAncestorPrefabInstance;
    /** 在 PrefabInstance.propertyOverrides 中创建或更新属性覆写条目。
     *  @param prefabInstance  cc.PrefabInstance 对象
     *  @param targetComp      被覆写属性的组件对象（需有 __prefab → CompPrefabInfo）
     *  @param property        属性名（如 spriteFrame），内部自动补 _ 前缀
     *  @param newValue        新值（已解析过的值，可能为 {__uuid__:...} 等）
     *  @returns 'created' | 'updated' */
    private _upsertPropertyOverride;
    private static _normalizeValue;
    /** 解析 hex 颜色字符串（#RGB, #RRGGBB, #RRGGBBAA）→ {r,g,b,a} 0-255 */
    private static _parseHexColor;
    private static _remapRefs;
    private static _remapObjRefs;
}
export {};
//# sourceMappingURL=document.d.ts.map