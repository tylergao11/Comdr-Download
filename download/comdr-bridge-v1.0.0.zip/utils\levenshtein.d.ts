export declare function levenshtein(a: string, b: string, maxDist?: number): number;
//# sourceMappingURL=levenshtein.d.ts.map